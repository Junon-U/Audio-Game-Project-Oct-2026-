extends Node2D
## Top-down cave explorer drawn in code: shadow, backpack, body, arms,
## helmet with a headlamp. Faces the direction of movement.

var facing := Vector2.UP
var walk_phase := 0.0


func set_facing(dir: Vector2) -> void:
	if dir.length() > 0.01:
		facing = dir.normalized()
		rotation = facing.angle() + PI / 2.0


func step(delta: float, moving: bool) -> void:
	walk_phase = walk_phase + delta * 12.0 if moving else 0.0
	queue_redraw()


func _draw() -> void:
	var swing := sin(walk_phase) * 4.0
	# Shadow
	draw_set_transform(Vector2(3, 5), 0, Vector2(1.0, 0.85))
	draw_circle(Vector2.ZERO, 30, Color(0, 0, 0, 0.25))
	draw_set_transform(Vector2.ZERO, 0, Vector2.ONE)
	# Backpack
	draw_rect(Rect2(-15, 8, 30, 18), Color(0.36, 0.26, 0.18))
	draw_rect(Rect2(-15, 8, 30, 18), Color(0.2, 0.14, 0.1), false, 2.0)
	# Arms
	draw_circle(Vector2(-22, -2 + swing), 7, Color(0.33, 0.42, 0.55))
	draw_circle(Vector2(22, -2 - swing), 7, Color(0.33, 0.42, 0.55))
	# Body
	draw_set_transform(Vector2.ZERO, 0, Vector2(1.0, 0.75))
	draw_circle(Vector2.ZERO, 22, Color(0.28, 0.37, 0.50))
	draw_arc(Vector2.ZERO, 22, 0, TAU, 40, Color(0.14, 0.19, 0.27), 2.5, true)
	draw_set_transform(Vector2.ZERO, 0, Vector2.ONE)
	# Helmet
	draw_circle(Vector2(0, -2), 14, Color(0.95, 0.75, 0.2))
	draw_arc(Vector2(0, -2), 14, 0, TAU, 32, Color(0.55, 0.4, 0.08), 2.0, true)
	# Headlamp
	draw_circle(Vector2(0, -15), 4.5, Color(1.0, 0.97, 0.8))
	draw_arc(Vector2(0, -15), 4.5, 0, TAU, 16, Color(0.45, 0.4, 0.3), 1.5, true)
