extends Node2D
## Chalk arrow drawn on the cave floor, pointing in its node's +x direction.
## It is part of the lit world, so the lantern level controls how visible it is.

var size := 56.0
var width := 6.0
var alpha := 0.85


func _draw() -> void:
	var c := Color(0.97, 0.96, 0.92, alpha)
	var h := size / 2.0
	draw_line(Vector2(-h, 0), Vector2(h, 0), c, width, true)
	draw_line(Vector2(h, 0), Vector2(h - size * 0.38, -size * 0.32), c, width, true)
	draw_line(Vector2(h, 0), Vector2(h - size * 0.38, size * 0.32), c, width, true)
