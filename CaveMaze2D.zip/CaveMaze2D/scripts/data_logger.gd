extends RefCounted
## Writes trial, event and movement-path CSV files and sends event markers over UDP.
## Timestamps: t_us = Time.get_ticks_usec() (monotonic, microseconds since start).
## tools/lsl_bridge.py re-stamps each marker on the LSL clock when it arrives.

const TRIAL_COLUMNS := [
	"pid", "mode", "block", "epoch", "trial_global", "trial_in_block",
	"reliability", "reliability_condition", "audio_cond", "visibility",
	"correct_exit", "cue_exit", "chalk_exit", "chalk_valid",
	"choice_exit", "choice_device", "correct", "followed_sound", "followed_chalk", "timeout", "rt_ms",
	"first_move_ms", "first_move_angle_deg", "first_move_exit",
	"first_move_to_sound", "first_move_to_target", "first_move_to_chalk", "path_length_px",
	"early_inputs", "preview_ms", "depth",
	"cue_valid", "cue_chalk", "n_audio_prev", "n_valid_prev", "r_hat",
	"correct_x", "correct_y", "cue_x", "cue_y", "chalk_x", "chalk_y",
	"t_start_us", "t_scene_us", "t_cue_us", "t_response_us", "t_feedback_us",
]

var data_dir := ""
var base_name := ""
var trials_file: FileAccess
var events_file: FileAccess
var path_file: FileAccess
var extra_files := {}     # suffix -> FileAccess (ratings, questionnaire)
var udp := PacketPeerUDP.new()
var udp_enabled := false
var pid := ""


static func resolve_data_dir() -> String:
	var base: String
	if OS.has_feature("editor"):
		base = ProjectSettings.globalize_path("res://")
	else:
		base = OS.get_executable_path().get_base_dir()
	var d := base.path_join("data")
	DirAccess.make_dir_recursive_absolute(d)
	return d


func open(p_pid: String, mode: String, cfg: ConfigFile) -> void:
	pid = p_pid
	data_dir = resolve_data_dir()
	var stamp := Time.get_datetime_string_from_system().replace(":", "-").replace("T", "_")
	base_name = "%s_%s_%s" % [pid, mode, stamp]
	trials_file = FileAccess.open(path_of("_trials.csv"), FileAccess.WRITE)
	events_file = FileAccess.open(path_of("_events.csv"), FileAccess.WRITE)
	path_file = FileAccess.open(path_of("_paths.csv"), FileAccess.WRITE)
	trials_file.store_line(",".join(TRIAL_COLUMNS))
	events_file.store_line("t_us,unix_time,event,trial_global,details")
	path_file.store_line("trial_global,t_us,x_px,y_px")

	udp_enabled = bool(cfg.get_value("network", "udp_enabled", true))
	if udp_enabled:
		var host := str(cfg.get_value("network", "udp_host", "127.0.0.1"))
		var port := int(cfg.get_value("network", "udp_port", 12345))
		if udp.set_dest_address(host, port) != OK:
			push_warning("UDP marker output disabled")
			udp_enabled = false


func path_of(suffix: String) -> String:
	return data_dir.path_join(base_name + suffix)


## Logs an event, sends it as a marker, returns its timestamp.
func event(name: String, trial_global: int = -1, details: Dictionary = {}) -> int:
	var t := Time.get_ticks_usec()
	var det := JSON.stringify(details) if not details.is_empty() else ""
	if events_file:
		events_file.store_line("%d,%.6f,%s,%d,\"%s\"" % [t, Time.get_unix_time_from_system(),
				name, trial_global, det.replace("\"", "\"\"")])
	if udp_enabled:
		var msg := {"event": name, "trial": trial_global, "t_us": t, "pid": pid}
		msg.merge(details)
		udp.put_packet(JSON.stringify(msg).to_utf8_buffer())
	return t


func path_sample(trial_global: int, pos: Vector2) -> void:
	if path_file:
		path_file.store_line("%d,%d,%.1f,%.1f" % [trial_global, Time.get_ticks_usec(), pos.x, pos.y])


func trial(row: Dictionary) -> void:
	if trials_file == null:
		return
	var vals: PackedStringArray = []
	for c in TRIAL_COLUMNS:
		var v = row.get(c, "")
		var s := str(v)
		if s.contains(","):
			s = "\"" + s + "\""
		vals.append(s)
	trials_file.store_line(",".join(vals))
	trials_file.flush()
	events_file.flush()
	path_file.flush()


## Appends one row to an extra CSV file (created with a header on first use).
func append_csv(suffix: String, columns: Array, row: Dictionary) -> void:
	if not extra_files.has(suffix):
		var f := FileAccess.open(path_of(suffix), FileAccess.WRITE)
		if f == null:
			return
		f.store_line(",".join(columns))
		extra_files[suffix] = f
	var vals: PackedStringArray = []
	for c in columns:
		var s := str(row.get(c, ""))
		if s.contains(",") or s.contains("\"") or s.contains("\n"):
			s = "\"" + s.replace("\"", "\"\"").replace("\n", " ") + "\""
		vals.append(s)
	extra_files[suffix].store_line(",".join(vals))
	extra_files[suffix].flush()


func write_json(suffix: String, data: Dictionary) -> void:
	var f := FileAccess.open(path_of(suffix), FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data, "  "))
		f.close()


func close() -> void:
	for f in [trials_file, events_file, path_file]:
		if f:
			f.close()
	for f in extra_files.values():
		f.close()
	extra_files.clear()
	trials_file = null
	events_file = null
	path_file = null
	udp.close()
