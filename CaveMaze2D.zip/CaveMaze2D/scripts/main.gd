extends Node2D
## Cave Maze: experiment controller (top-down 2D junction maze).
##
## The explorer descends through a cave. Every junction is one trial: the
## explorer stands at the centre of a four-way junction (arrived from below)
## and must pick one of three exits: left, ahead or right. One exit leads down
## (a trapdoor); the other two are dead ends. Two imperfect sources of evidence:
##   sound   the guide's double pickaxe tap from one corridor
##           (valid / invalid / silent; reliability set per epoch)
##   vision  a chalk arrow at one exit (valid on chalk_reliability of junctions),
##           either clear or faded (visual uncertainty; screen brightness matched)
##
## Trial timeline ([timing] in config/experiment.cfg):
##   start (lantern low, look at the explorer) -> lantern up, movement locked
##   (preview) -> cue onset -> response window -> walk into the corridor ->
##   feedback (+ fixed penalty for a dead end or timeout) -> black ITI
##
## Modes:
##   live          steer the explorer with WASD / arrow keys into a corridor
##   replay        press LEFT / UP / RIGHT (or A / W / D); the explorer walks there
##   localization  taps only; press the direction they came from
##
## Command-line options (after "--"):
##   --autotest[-mode=replay|localization]  short simulated session, then quit
##   --make-schedule=<ID>                   write schedules/<ID>.csv and quit
##   --shots                                save screenshots to data/screenshots

const Schedule := preload("res://scripts/schedule.gd")
const DataLogger := preload("res://scripts/data_logger.gd")
const Explorer := preload("res://scripts/explorer.gd")
const ChalkArrow := preload("res://scripts/chalk_arrow.gd")

const REF := Vector2(1920, 1080)
const EXIT_NAMES := ["left", "ahead", "right"]
const EXIT_DIRS := [Vector2.LEFT, Vector2.UP, Vector2.RIGHT]

var cfg := ConfigFile.new()
var logger: DataLogger
var rng := RandomNumberGenerator.new()

var centre := Vector2(960, 540)
var junction: Sprite2D
var props: Node2D
var explorer: Node2D
var lantern: PointLight2D
var chalk: Node2D

var cue_streams: Array[AudioStream] = []
var cue_player: AudioStreamPlayer
var amb_player: AudioStreamPlayer
var step_player: AudioStreamPlayer
var fb_player: AudioStreamPlayer
var fx_player: AudioStreamPlayer
var step_streams: Array[AudioStream] = []
var sounds := {}

# UI
var ui: CanvasLayer
var blackout: ColorRect
var message: Label
var banner: Label
var hint: Label
var hud: Label
var menu: Control
var pid_edit: LineEdit
var mode_select: OptionButton
var fullscreen_check: CheckBox
var menu_info: Label

# Session state
var pid := ""
var mode := "live"
var depth := 0
var stage_label := ""
var stage_title: Label
var stage_sub: Label
var stage_hint: Label
var time_scale := 1.0
var autotest := false
var aborting := false
var escape_presses := 0
var pause_requested := false
# Reliability estimate from the proposal: (a0 + previous valid cues) /
# (a0 + b0 + previous audio trials); silent junctions do not update it.
var n_audio_prev := 0
var n_valid_prev := 0
# Extra screens
var reveal_light: PointLight2D
var val_target: Control
var rating_ui: Control
var rating_q: Label
var rating_fill: ColorRect
var rating_value: Label
var rating_left: Label
var rating_right: Label
var rating_hint: Label
var choice_label: Label
var text_edit: LineEdit


# ================================================================ setup

func _ready() -> void:
	if cfg.load("res://config/experiment.cfg") != OK:
		push_warning("config/experiment.cfg not found; using defaults")
	centre = Vector2(_m("centre_x", 960.0), _m("centre_y", 540.0))
	_setup_input()
	_build_world()
	_build_audio()
	_build_ui()

	var args := OS.get_cmdline_user_args()
	for a in args:
		if a.begins_with("--make-schedule="):
			_make_schedule_file(a.get_slice("=", 1))
			return
	if "--shots" in args:
		_take_screenshots()
		return
	for a in args:
		if a == "--autotest":
			autotest = true
		elif a.begins_with("--autotest-mode="):
			autotest = true
			mode = a.get_slice("=", 1)
	if autotest:
		time_scale = 0.1
		cfg.set_value("design", "trials_per_epoch", 12)
		cfg.set_value("design", "practice_trials", 3)
		cfg.set_value("design", "localization_reps", 2)
		pid = "AUTOTEST"
		for a in args:
			if a.begins_with("--autotest-pid="):
				pid = a.get_slice("=", 1)
		menu.visible = false
		_run_session()
	else:
		_show_menu()


func _m(key: String, default_value: float) -> float:
	return float(cfg.get_value("maze", key, default_value))


func _setup_input() -> void:
	var keys := {
		"move_up": [KEY_W, KEY_UP], "move_down": [KEY_S, KEY_DOWN],
		"move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT],
		"continue": [KEY_SPACE, KEY_ENTER, KEY_KP_ENTER], "abort": [KEY_ESCAPE],
		"pause": [KEY_P], "validate": [KEY_V],
	}
	for action in keys:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for k in keys[action]:
			var ev := InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(action, ev)


func _build_world() -> void:
	var dark := CanvasModulate.new()
	var amb := float(cfg.get_value("lantern", "ambient", 0.04))
	dark.color = Color(amb, amb, amb)
	add_child(dark)

	junction = Sprite2D.new()
	junction.texture = load("res://assets/sprites/junction.png")
	junction.centered = false
	add_child(junction)

	chalk = ChalkArrow.new()
	chalk.size = _m("chalk_size_px", 56.0)
	chalk.width = _m("chalk_width_px", 6.0)
	chalk.visible = false
	add_child(chalk)

	props = Node2D.new()
	add_child(props)

	explorer = Explorer.new()
	explorer.scale = Vector2.ONE * 1.3
	add_child(explorer)

	# Lantern: a soft radial light that follows the explorer.
	var grad := Gradient.new()
	grad.set_color(0, Color(1.0, 0.92, 0.78, 1.0))
	grad.set_color(1, Color(1.0, 0.92, 0.78, 0.0))
	grad.add_point(0.55, Color(1.0, 0.92, 0.78, 0.75))
	var tex := GradientTexture2D.new()
	tex.gradient = grad
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.5)
	tex.width = 512
	tex.height = 512
	lantern = PointLight2D.new()
	lantern.texture = tex
	add_child(lantern)
	reveal_light = PointLight2D.new()
	reveal_light.texture = tex
	reveal_light.energy = 1.1
	reveal_light.texture_scale = 220.0 / 256.0
	reveal_light.visible = false
	add_child(reveal_light)


func _process(_delta: float) -> void:
	lantern.position = explorer.position


## Lantern settings for "start" ([lantern]) or a visibility level ([visibility]).
func _lantern_values(level: String) -> Vector2:
	if level == "start":
		return Vector2(float(cfg.get_value("lantern", "start_energy", 0.6)),
				float(cfg.get_value("lantern", "start_radius_px", 110.0)))
	return Vector2(float(cfg.get_value("visibility", level + "_lantern_energy", 1.25)),
			float(cfg.get_value("visibility", level + "_lantern_radius_px", 560.0)))


func _set_lantern(level: String) -> void:
	var v := _lantern_values(level)
	lantern.energy = v.x
	lantern.texture_scale = v.y / 256.0


func _tween_lantern(level: String, seconds: float) -> void:
	var v := _lantern_values(level)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(lantern, "energy", v.x, seconds)
	tw.tween_property(lantern, "texture_scale", v.y / 256.0, seconds)


func _set_chalk(level: String) -> void:
	chalk.alpha = float(cfg.get_value("visibility", level + "_chalk_alpha", 0.85))
	chalk.queue_redraw()


func _load(path: String) -> AudioStream:
	if ResourceLoader.exists(path):
		return load(path)
	push_warning("Missing audio file: %s (run tools/make_stimuli.py)" % path)
	return null


func _build_audio() -> void:
	for e in 3:
		cue_streams.append(_load("res://audio/stimuli/cue_%02d.wav" % e))
	for k in 5:
		step_streams.append(_load("res://assets/kenney_audio/footstep_concrete_%03d.ogg" % k))
	sounds["success"] = _load("res://assets/kenney_audio/confirmation_001.ogg")
	sounds["fail"] = _load("res://assets/kenney_audio/error_004.ogg")
	sounds["thud"] = _load("res://assets/kenney_audio/impactSoft_heavy_000.ogg")
	sounds["boards"] = _load("res://assets/kenney_audio/impactWood_light_000.ogg")
	sounds["stage"] = _load("res://assets/kenney_audio/maximize_006.ogg")
	cue_player = _player("cue_volume_db", 0.0)
	step_player = _player("footsteps_volume_db", -18.0)
	fb_player = _player("feedback_volume_db", -10.0)
	fx_player = _player("feedback_volume_db", -10.0)
	amb_player = _player("ambience_volume_db", -30.0)
	amb_player.stream = _load("res://audio/ambience_loop.wav")
	amb_player.finished.connect(amb_player.play)


func _player(key: String, default_db: float) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.volume_db = float(cfg.get_value("audio", key, default_db))
	add_child(p)
	return p


func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	blackout = ColorRect.new()
	blackout.color = Color.BLACK
	blackout.set_anchors_preset(Control.PRESET_FULL_RECT)
	blackout.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(blackout)

	message = _label("", 30, Vector4(0.12, 0.05, 0.88, 0.95))
	message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	banner = _label("", 34, Vector4(0, 0, 1, 0))
	banner.offset_top = 14
	banner.offset_bottom = 70
	hint = _label("", 24, Vector4(0, 1, 1, 1))
	hint.offset_top = -80
	hint.offset_bottom = -20
	hud = _label("", 26, Vector4(0, 0, 0, 0))
	hud.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	hud.offset_left = 40
	hud.offset_top = 24
	hud.offset_right = 900
	hud.offset_bottom = 70
	_build_extra_ui()
	stage_title = _label("", 78, Vector4(0, 0.26, 1, 0.42))
	stage_sub = _label("", 36, Vector4(0, 0.42, 1, 0.52))
	stage_hint = _label("", 24, Vector4(0, 0.64, 1, 0.72))
	stage_title.add_theme_color_override("font_color", Color(1.0, 0.85, 0.55))
	for l in [stage_title, stage_sub, stage_hint]:
		l.visible = false
	for l in [banner, hint, hud]:
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
		l.add_theme_constant_override("outline_size", 8)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui.add_child(center)
	menu = center
	var panel := PanelContainer.new()
	center.add_child(panel)
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	panel.add_child(margin)
	var box := VBoxContainer.new()
	box.custom_minimum_size = Vector2(600, 0)
	box.add_theme_constant_override("separation", 14)
	margin.add_child(box)
	var title := Label.new()
	title.text = "Cave Maze - experimenter setup"
	title.add_theme_font_size_override("font_size", 26)
	box.add_child(title)
	pid_edit = LineEdit.new()
	pid_edit.placeholder_text = "Participant ID (e.g. P001)"
	box.add_child(pid_edit)
	var cond_label := Label.new()
	cond_label.add_theme_font_size_override("font_size", 16)
	box.add_child(cond_label)
	pid_edit.text_changed.connect(func(t: String):
		var id := t.strip_edges()
		if id.is_empty():
			cond_label.text = ""
			return
		var a := Schedule.assign_reliability(id, cfg)
		cond_label.text = "Sound reliability: epoch 1 %d%%, epoch 2 %d%%, epoch 3 %d%%  (condition %d of %d, %s)" % [
				round(a["r1"] * 100), round(a["r2"] * 100), round(a["r3"] * 100),
				a["condition"], a["n_conditions"], a["method"]])
	mode_select = OptionButton.new()
	mode_select.add_item("Live play")
	mode_select.add_item("Replay")
	mode_select.add_item("Localization test")
	box.add_child(mode_select)
	fullscreen_check = CheckBox.new()
	fullscreen_check.text = "Fullscreen"
	fullscreen_check.button_pressed = true
	box.add_child(fullscreen_check)
	var start := Button.new()
	start.text = "Start"
	start.pressed.connect(_on_start_pressed)
	box.add_child(start)
	menu_info = Label.new()
	menu_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	menu_info.custom_minimum_size = Vector2(600, 0)
	menu_info.add_theme_font_size_override("font_size", 14)
	menu_info.text = "Data folder: %s\nSchedules: schedules/<ID>.csv is used if present, otherwise one is generated from the ID." % DataLogger.resolve_data_dir()
	box.add_child(menu_info)


## Screens for ratings, multiple-choice questions, free text and gaze validation.
## Coordinates are in the 1920x1080 reference frame.
func _build_extra_ui() -> void:
	rating_ui = Control.new()
	rating_ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	rating_ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rating_ui.visible = false
	ui.add_child(rating_ui)
	rating_q = Label.new()
	rating_q.add_theme_font_size_override("font_size", 34)
	rating_q.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rating_q.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rating_q.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	rating_q.position = Vector2(260, 160)
	rating_q.size = Vector2(1400, 260)
	rating_ui.add_child(rating_q)
	var bar := ColorRect.new()
	bar.color = Color(0.25, 0.25, 0.25)
	bar.position = Vector2(460, 560)
	bar.size = Vector2(1000, 36)
	bar.name = "bar"
	rating_ui.add_child(bar)
	rating_fill = ColorRect.new()
	rating_fill.color = Color(1.0, 0.8, 0.45)
	rating_fill.position = Vector2(460, 560)
	rating_fill.size = Vector2(500, 36)
	rating_ui.add_child(rating_fill)
	rating_value = Label.new()
	rating_value.add_theme_font_size_override("font_size", 48)
	rating_value.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rating_value.position = Vector2(760, 470)
	rating_value.size = Vector2(400, 70)
	rating_ui.add_child(rating_value)
	rating_left = Label.new()
	rating_left.add_theme_font_size_override("font_size", 24)
	rating_left.position = Vector2(460, 610)
	rating_left.size = Vector2(480, 80)
	rating_left.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rating_ui.add_child(rating_left)
	rating_right = Label.new()
	rating_right.add_theme_font_size_override("font_size", 24)
	rating_right.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	rating_right.position = Vector2(980, 610)
	rating_right.size = Vector2(480, 80)
	rating_right.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rating_ui.add_child(rating_right)
	choice_label = Label.new()
	choice_label.add_theme_font_size_override("font_size", 32)
	choice_label.position = Vector2(740, 470)
	choice_label.size = Vector2(900, 380)
	rating_ui.add_child(choice_label)
	text_edit = LineEdit.new()
	text_edit.position = Vector2(360, 520)
	text_edit.size = Vector2(1200, 60)
	text_edit.add_theme_font_size_override("font_size", 28)
	text_edit.placeholder_text = "Type here (optional), then press ENTER"
	rating_ui.add_child(text_edit)
	rating_hint = Label.new()
	rating_hint.add_theme_font_size_override("font_size", 24)
	rating_hint.modulate = Color(1, 1, 1, 0.6)
	rating_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rating_hint.position = Vector2(260, 900)
	rating_hint.size = Vector2(1400, 60)
	rating_ui.add_child(rating_hint)

	val_target = Control.new()
	val_target.mouse_filter = Control.MOUSE_FILTER_IGNORE
	val_target.visible = false
	val_target.draw.connect(func():
		val_target.draw_circle(Vector2.ZERO, 18, Color.WHITE)
		val_target.draw_circle(Vector2.ZERO, 4, Color.BLACK))
	ui.add_child(val_target)


func _label(text: String, size: int, anchors: Vector4) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(l)
	l.anchor_left = anchors.x
	l.anchor_top = anchors.y
	l.anchor_right = anchors.z
	l.anchor_bottom = anchors.w
	l.offset_left = 0
	l.offset_top = 0
	l.offset_right = 0
	l.offset_bottom = 0
	return l


func _show_menu() -> void:
	blackout.visible = true
	menu.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	pid_edit.grab_focus()


func _on_start_pressed() -> void:
	pid = pid_edit.text.strip_edges()
	if pid.is_empty():
		menu_info.text = "Please enter a participant ID."
		return
	mode = ["live", "replay", "localization"][mode_select.selected]
	if fullscreen_check.button_pressed:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	menu.visible = false
	_run_session()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause") and not menu.visible and logger != null:
		pause_requested = true
		hint.text = "Pausing after this junction..."
	if event.is_action_pressed("abort") and not menu.visible:
		escape_presses += 1
		hint.text = "Aborting after this junction..." if escape_presses >= 2 else "Press ESC again to abort the session."
		aborting = escape_presses >= 2


# ================================================================ helpers

func _ms(ms: float) -> float:
	return ms / 1000.0 * time_scale


func _wait(ms: float) -> void:
	if ms > 0.0:
		await get_tree().create_timer(_ms(ms)).timeout


func _t(key: String, default_value: float) -> float:
	return float(cfg.get_value("timing", key, default_value))


func _wait_continue(text: String) -> void:
	blackout.visible = true
	message.text = text + "\n\n[Press SPACE to continue]"
	message.visible = true
	if autotest:
		await _wait(300)
	else:
		await get_tree().process_frame
		while not Input.is_action_just_pressed("continue"):
			await get_tree().process_frame
	message.visible = false


func _play(p: AudioStreamPlayer, s: AudioStream) -> void:
	if s != null:
		p.stream = s
		p.play()


func exit_point(e: int, dist: float) -> Vector2:
	return centre + EXIT_DIRS[e] * dist


## Angle in degrees, clockwise from straight up (screen).
static func _cw_angle(v: Vector2) -> float:
	return fposmod(rad_to_deg(atan2(v.x, -v.y)), 360.0)


## Exit closest in direction to a displacement from the centre.
func _exit_by_direction(v: Vector2) -> int:
	var best := 0
	var best_dot := -INF
	for e in 3:
		var d: float = v.normalized().dot(EXIT_DIRS[e])
		if d > best_dot:
			best_dot = d
			best = e
	return best


## Keeps the explorer on the corridor floor (cross-shaped, no way back down).
func _walkable(p: Vector2) -> bool:
	var hw := _m("corridor_half_width_px", 105.0)
	var d := p - centre
	if abs(d.y) <= hw:
		return true
	return abs(d.x) <= hw and d.y <= hw


func _key_choice() -> int:
	if Input.is_action_just_pressed("move_left"):
		return 0
	if Input.is_action_just_pressed("move_up"):
		return 1
	if Input.is_action_just_pressed("move_right"):
		return 2
	return -1


func _clear_props() -> void:
	for c in props.get_children():
		c.queue_free()


func _reset_explorer() -> void:
	explorer.position = centre
	explorer.set_facing(Vector2.UP)
	explorer.step(0.0, false)
	lantern.position = centre


# ================================================================ session

func _run_session() -> void:
	logger = DataLogger.new()
	logger.open(pid, mode, cfg)
	rng.seed = hash(pid + mode)
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	_play(amb_player, amb_player.stream)

	var rows: Array
	if mode == "localization":
		rows = Schedule.new().generate_localization(pid, cfg)
	else:
		rows = Schedule.load_csv(_schedule_dir().path_join(pid + ".csv"))
		if rows.is_empty():
			rows = Schedule.new().generate(pid, cfg)
	Schedule.save_csv(rows, logger.path_of("_schedule.csv"))
	_write_session_meta(rows.size())
	logger.event("session_start", -1, {"mode": mode, "n_trials": rows.size()})

	if mode == "localization":
		await _run_localization(rows)
	else:
		await _run_main(rows)
		await _run_validation("end")
		if bool(cfg.get_value("questionnaire", "enabled", true)):
			await _questionnaire()

	logger.event("session_end", -1, {"aborted": aborting})
	logger.close()
	amb_player.stop()
	if autotest:
		print("AUTOTEST finished: ", logger.path_of("_trials.csv"))
		get_tree().quit()
		return
	await _wait_continue("The session is complete. Thank you!\n\nData saved to:\n%s" % logger.data_dir)
	get_tree().quit()


func _schedule_dir() -> String:
	if OS.has_feature("editor"):
		return ProjectSettings.globalize_path("res://schedules")
	return OS.get_executable_path().get_base_dir().path_join("schedules")


func _make_schedule_file(sid: String) -> void:
	DirAccess.make_dir_recursive_absolute(_schedule_dir())
	var path := _schedule_dir().path_join(sid + ".csv")
	Schedule.save_csv(Schedule.new().generate(sid, cfg), path)
	print("Schedule written: ", path)
	get_tree().quit()


func _write_session_meta(n_rows: int) -> void:
	var win := Vector2(get_window().size)
	var scale_f: float = min(win.x / REF.x, win.y / REF.y)
	var exits := []
	var aoi := _m("exit_aoi_distance_px", 330.0)
	var cd := _m("chalk_distance_px", 190.0)
	for e in 3:
		var p := exit_point(e, aoi)
		var c := exit_point(e, cd)
		exits.append({"exit": e, "name": EXIT_NAMES[e], "aoi_x": p.x, "aoi_y": p.y, "chalk_x": c.x, "chalk_y": c.y})
	var cfg_dump := {}
	for section in cfg.get_sections():
		var s := {}
		for key in cfg.get_section_keys(section):
			s[key] = cfg.get_value(section, key)
		cfg_dump[section] = s
	logger.write_json("_session.json", {
		"pid": pid, "mode": mode, "n_rows": n_rows, "autotest": autotest,
		"reliability_assignment": Schedule.assign_reliability(pid, cfg),
		"started": Time.get_datetime_string_from_system(),
		"godot_version": Engine.get_version_info()["string"],
		"reference_frame_px": [REF.x, REF.y],
		"window_px": [win.x, win.y],
		"reference_to_window_scale": scale_f,
		"reference_to_window_offset_px": [(win.x - REF.x * scale_f) / 2.0, (win.y - REF.y * scale_f) / 2.0],
		"screen_refresh_hz": DisplayServer.screen_get_refresh_rate(),
		"audio_output_latency_s": AudioServer.get_output_latency(),
		"audio_mix_rate": AudioServer.get_mix_rate(),
		"centre_px": [centre.x, centre.y],
		"exit_codes": {"0": "left", "1": "ahead", "2": "right", "-1": "none"},
		"exits": exits,
		"config": cfg_dump,
	})


func _instructions() -> String:
	var how := ("Steer the explorer with  W A S D  or the arrow keys and walk into the tunnel you choose."
			if mode == "live" else
			"Press  LEFT,  UP  or  RIGHT  (or A, W, D) to choose a tunnel; the explorer walks there.")
	return ("You are descending through a deep cave.\n\n"
		+ "At every junction, one of the three tunnels (left, ahead, right) leads further down. "
		+ "The other two are dead ends that cost you time.\n\n"
		+ "Your guide, somewhere below, taps the rock twice down the right tunnel. Caves echo, so the "
		+ "tap may sometimes seem to come from the wrong tunnel, and sometimes there is no tap at all.\n"
		+ "Earlier explorers drew chalk arrows on the floor. They are usually, but not always, right, "
		+ "and some have faded and are hard to see.\n\n"
		+ how + "\nYou can only move after the tap (or a short wait). Be fast and accurate.\n\n"
		+ "At the start of each junction, look at the explorer in the centre.")


func _run_main(rows: Array) -> void:
	await _run_validation("start")
	await _wait_continue(_instructions())
	depth = 0
	n_audio_prev = 0
	n_valid_prev = 0
	_update_hud()
	var current := ""
	var current_epoch := 0
	var g := 0
	for row in rows:
		if aborting:
			break
		if row["block"] != current:
			if current != "":
				logger.event("block_end", g, {"block": current})
				hud.visible = false
				if current_epoch > 0:
					await _level_ratings(current_epoch, float(rows[g - 1]["reliability"]))
				await _wait_continue("Practice complete. The real descent starts now." if current == "practice" else "Take a short rest.")
				if current != "practice":
					await _run_validation("rest_after_level_%d" % current_epoch)
			current = row["block"]
			current_epoch = int(row["epoch"])
			logger.event("block_start", g + 1, {"block": current})
			if int(row["epoch"]) > 0:
				await _stage_card(int(row["epoch"]), g + 1)
			else:
				stage_label = "Practice"
				_update_hud()
		if pause_requested:
			await _pause_screen(g)
		g += 1
		hud.visible = true
		_add_estimate(row)
		var res := await _run_trial(row, g)
		logger.trial(res)
		_update_estimate(row)
	if current != "":
		logger.event("block_end", g, {"block": current})
		hud.visible = false
		if current_epoch > 0 and not aborting:
			await _level_ratings(current_epoch, float(rows[g - 1]["reliability"]))
	hud.visible = false


func _counts_for_estimate(row: Dictionary) -> bool:
	return int(row["epoch"]) > 0 or bool(cfg.get_value("estimate", "include_practice", false))


## Adds the proposal's reliability estimate (state before this junction) to the row.
func _add_estimate(row: Dictionary) -> void:
	var cue: int = row["cue_exit"]
	var ch: int = row["chalk_exit"]
	row["cue_valid"] = "" if cue < 0 else (1 if cue == int(row["correct_exit"]) else 0)
	row["cue_chalk"] = "no_cue" if cue < 0 else ("agree" if cue == ch else "conflict")
	if not _counts_for_estimate(row):
		row["n_audio_prev"] = ""
		row["n_valid_prev"] = ""
		row["r_hat"] = ""
		return
	var a0 := float(cfg.get_value("estimate", "alpha0", 1.0))
	var b0 := float(cfg.get_value("estimate", "beta0", 1.0))
	row["n_audio_prev"] = n_audio_prev
	row["n_valid_prev"] = n_valid_prev
	row["r_hat"] = snappedf((a0 + n_valid_prev) / (a0 + b0 + n_audio_prev), 0.0001)


func _update_estimate(row: Dictionary) -> void:
	if _counts_for_estimate(row) and int(row["cue_exit"]) >= 0:
		n_audio_prev += 1
		if int(row["cue_exit"]) == int(row["correct_exit"]):
			n_valid_prev += 1


func _stage_title(epoch: int) -> String:
	var titles: Array = cfg.get_value("stages", "titles", [])
	return titles[epoch - 1] if epoch - 1 < titles.size() else ""


func _update_hud() -> void:
	var show_stage := bool(cfg.get_value("stages", "show_in_hud", true)) and not stage_label.is_empty()
	hud.text = (stage_label + "      Depth: %d" % depth) if show_stage else "Depth: %d" % depth


## Title card shown when a new level (reliability epoch) begins.
func _stage_card(epoch: int, g: int) -> void:
	stage_label = "Level %d" % epoch
	_update_hud()
	if not bool(cfg.get_value("stages", "announce", true)):
		return
	hud.visible = false
	blackout.visible = true
	stage_title.text = "Level %d" % epoch
	stage_sub.text = _stage_title(epoch)
	stage_hint.text = "Depth so far: %d" % depth
	for l in [stage_title, stage_sub, stage_hint]:
		l.visible = true
		l.modulate.a = 0.0
		create_tween().tween_property(l, "modulate:a", 1.0, _ms(500))
	_play(fb_player, sounds["stage"])
	if logger:
		logger.event("stage_card", g, {"epoch": epoch, "title": stage_sub.text})
	await _wait(float(cfg.get_value("stages", "card_min_ms", 1500)))
	if autotest:
		await _wait(200)
	else:
		stage_hint.text = "Depth so far: %d\n\n[Press SPACE to continue]" % depth
		await get_tree().process_frame
		while not Input.is_action_just_pressed("continue"):
			await get_tree().process_frame
	for l in [stage_title, stage_sub, stage_hint]:
		l.visible = false


func _run_trial(row: Dictionary, g: int) -> Dictionary:
	var res: Dictionary = row.duplicate()
	res["pid"] = pid
	res["mode"] = mode
	res["trial_global"] = g
	var correct: int = row["correct_exit"]
	var cue: int = row["cue_exit"]
	var chalk_e: int = row["chalk_exit"]
	var aoi := _m("exit_aoi_distance_px", 330.0)
	var cp := exit_point(correct, aoi)
	res["correct_x"] = cp.x
	res["correct_y"] = cp.y
	res["cue_x"] = exit_point(cue, aoi).x if cue >= 0 else ""
	res["cue_y"] = exit_point(cue, aoi).y if cue >= 0 else ""
	var chp := exit_point(chalk_e, _m("chalk_distance_px", 190.0))
	res["chalk_x"] = chp.x
	res["chalk_y"] = chp.y

	# 1. Start: explorer at the centre, lantern turned down.
	reveal_light.visible = false
	_clear_props()
	_reset_explorer()
	chalk.visible = false
	_set_lantern("start")
	banner.text = ""
	blackout.visible = false
	res["t_start_us"] = logger.event("start_on", g)
	await _wait(_t("start_ms", 500))

	# 2. Scene: lantern up to this junction's level, chalk arrow visible; movement locked.
	chalk.position = chp
	chalk.rotation = EXIT_DIRS[chalk_e].angle()
	_set_chalk(row["visibility"])
	chalk.visible = true
	_tween_lantern(row["visibility"], _ms(150))
	res["t_scene_us"] = logger.event("scene_on", g, {"visibility": row["visibility"], "chalk_exit": chalk_e})
	var preview := rng.randf_range(_t("preview_min_ms", 1000), _t("preview_max_ms", 1500))
	res["preview_ms"] = snappedf(preview, 0.1)
	res["early_inputs"] = await _count_inputs_during(preview)

	# 3. Cue onset (or the silent slot).
	if cue >= 0 and cue_streams[cue] != null:
		cue_player.stream = cue_streams[cue]
		cue_player.play()
	var t_cue := logger.event("cue_on", g, {"audio_cond": row["audio_cond"], "cue_exit": cue})
	res["t_cue_us"] = t_cue

	# 4. Response
	var resp: Dictionary
	if mode == "live":
		resp = await _respond_live(g, t_cue, row)
	else:
		resp = await _respond_keys(t_cue, row)
	res.merge(resp, true)
	var choice: int = resp["choice_exit"]
	res["timeout"] = 1 if choice < 0 else 0
	res["correct"] = 1 if choice == correct else 0
	res["followed_sound"] = (1 if choice == cue else 0) if (cue >= 0 and choice >= 0) else ""
	res["followed_chalk"] = (1 if choice == chalk_e else 0) if choice >= 0 else ""
	if choice >= 0:
		res["rt_ms"] = snappedf((resp["t_response_us"] - t_cue) / 1000.0, 0.01)
		logger.event("response", g, {"choice_exit": choice, "correct": res["correct"], "rt_ms": res["rt_ms"]})
		await _walk_in(choice, correct)
	else:
		res["t_response_us"] = ""
		res["rt_ms"] = ""
		logger.event("timeout", g)

	# 5. Feedback
	var fb := _t("feedback_ms", 600)
	res["t_feedback_us"] = logger.event("feedback_on", g, {"correct": res["correct"], "timeout": res["timeout"]})
	if res["correct"] == 1:
		depth += 1
		_update_hud()
		banner.text = "The way down!"
		_play(fb_player, sounds["success"])
		_play(fx_player, sounds["boards"])
		await _wait(fb)
	else:
		banner.text = "Too slow - the guide moved on." if choice < 0 else "Dead end!"
		_play(fb_player, sounds["fail"])
		if choice >= 0:
			_play(fx_player, sounds["thud"])
		# Show where the way down was, so the tap's validity is visible on every
		# junction (the reliability estimate assumes it is known).
		if bool(cfg.get_value("feedback", "reveal_correct_on_error", true)):
			var tr := Sprite2D.new()
			tr.texture = load("res://assets/sprites/trapdoor.png")
			tr.scale = Vector2.ONE * 150.0 / float(tr.texture.get_width())
			tr.position = exit_point(correct, _m("reveal_distance_px", 420.0))
			tr.rotation = EXIT_DIRS[correct].angle() + PI / 2.0
			props.add_child(tr)
			reveal_light.position = tr.position
			reveal_light.visible = true
			logger.event("reveal_correct", g, {"correct_exit": correct})
		await _wait(fb + _t("dead_end_penalty_ms", 1000))
	res["depth"] = depth

	# 6. Inter-trial interval (black)
	banner.text = ""
	blackout.visible = true
	logger.event("iti_on", g)
	await _wait(_t("iti_ms", 500))
	return res


func _count_inputs_during(ms: float) -> int:
	var count := 0
	var end_us := Time.get_ticks_usec() + int(_ms(ms) * 1e6)
	while Time.get_ticks_usec() < end_us:
		await get_tree().process_frame
		for a in ["move_up", "move_down", "move_left", "move_right"]:
			if Input.is_action_just_pressed(a):
				count += 1
	return count


## Live mode: steer the explorer; walking far enough into a corridor selects it.
func _respond_live(g: int, t_cue: int, row: Dictionary) -> Dictionary:
	var speed := float(cfg.get_value("movement", "speed_px_s", 600.0)) / time_scale
	var thresh := float(cfg.get_value("movement", "first_move_threshold_px", 25.0))
	var choose_d := _m("choice_distance_px", 230.0)
	var end_us := t_cue + int(_ms(_t("response_window_ms", 2500)) * 1e6)
	var out := {"choice_exit": -1, "choice_device": "", "first_move_ms": "", "first_move_angle_deg": "",
			"first_move_exit": "", "first_move_to_sound": "", "first_move_to_target": "",
			"first_move_to_chalk": "", "path_length_px": 0.0}
	var path_len := 0.0
	var clock := 0.0
	var next_step := 0.0
	var auto := _auto_plan(t_cue, row)
	while Time.get_ticks_usec() < end_us:
		await get_tree().process_frame
		var dt := get_process_delta_time()
		clock += dt
		var now := Time.get_ticks_usec()
		var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
		if autotest and now >= auto["at"] and auto["exit"] >= 0:
			dir = EXIT_DIRS[auto["exit"]]
		var moving := dir.length() > 0.1
		if moving:
			var before := explorer.position
			var step: Vector2 = dir.normalized() * speed * dt
			# Slide along walls: try the full step, then each axis on its own.
			for cand in [before + step, before + Vector2(step.x, 0), before + Vector2(0, step.y)]:
				if _walkable(cand):
					explorer.position = cand
					break
			path_len += before.distance_to(explorer.position)
			explorer.set_facing(dir)
			if not cue_player.playing and clock >= next_step:
				_play(step_player, step_streams[rng.randi_range(0, step_streams.size() - 1)])
				next_step = clock + _ms(280)
		explorer.step(dt, moving)
		logger.path_sample(g, explorer.position)
		var off: Vector2 = explorer.position - centre
		if out["first_move_ms"] is String and off.length() >= thresh:
			var e := _exit_by_direction(off)
			out["first_move_ms"] = snappedf((now - t_cue) / 1000.0, 0.01)
			out["first_move_angle_deg"] = snappedf(_cw_angle(off), 0.1)
			out["first_move_exit"] = e
			out["first_move_to_sound"] = (1 if e == int(row["cue_exit"]) else 0) if int(row["cue_exit"]) >= 0 else ""
			out["first_move_to_target"] = 1 if e == int(row["correct_exit"]) else 0
			out["first_move_to_chalk"] = 1 if e == int(row["chalk_exit"]) else 0
			logger.event("first_move", g, {"angle_deg": out["first_move_angle_deg"], "exit": e})
		for e in 3:
			if off.dot(EXIT_DIRS[e]) >= choose_d:
				out["choice_exit"] = e
				out["choice_device"] = "auto" if autotest else "keys"
				out["t_response_us"] = now
				out["path_length_px"] = snappedf(path_len, 0.1)
				return out
	out["path_length_px"] = snappedf(path_len, 0.1)
	return out


## Replay mode (and localization): one key press chooses an exit.
func _respond_keys(t_cue: int, row: Dictionary) -> Dictionary:
	var end_us := t_cue + int(_ms(_t("response_window_ms", 2500)) * 1e6)
	var out := {"choice_exit": -1, "choice_device": ""}
	var auto := _auto_plan(t_cue, row)
	while Time.get_ticks_usec() < end_us:
		await get_tree().process_frame
		var now := Time.get_ticks_usec()
		var e := _key_choice()
		var device := "keys"
		if e < 0 and autotest and now >= auto["at"]:
			e = auto["exit"]
			device = "auto"
		if e >= 0:
			out["choice_exit"] = e
			out["choice_device"] = device
			out["t_response_us"] = now
			break
	return out


## Autotest only: when and where the simulated player responds.
func _auto_plan(t_cue: int, row: Dictionary) -> Dictionary:
	if not autotest:
		return {"at": 1 << 62, "exit": -1}
	var cue: int = row["cue_exit"]
	var e: int = cue if (cue >= 0 and rng.randf() < 0.7) else rng.randi_range(0, 2)
	if rng.randf() < 0.05:
		e = -1
	return {"at": t_cue + int(_ms(rng.randf_range(250, 700)) * 1e6), "exit": e}


## After a choice: walk into the corridor; the trapdoor or rubble appears ahead.
func _walk_in(e: int, correct_e: int) -> void:
	var is_way_down := e == correct_e
	var tex: Texture2D = load("res://assets/sprites/trapdoor.png") if is_way_down else load("res://assets/sprites/rubble.png")
	var s := Sprite2D.new()
	s.texture = tex
	var size := 150.0 if is_way_down else 170.0
	s.scale = Vector2.ONE * size / float(tex.get_width())
	s.position = exit_point(e, _m("reveal_distance_px", 420.0))
	s.rotation = EXIT_DIRS[e].angle() + PI / 2.0
	props.add_child(s)
	var start := explorer.position
	var target := exit_point(e, _m("walk_in_distance_px", 300.0))
	explorer.set_facing(EXIT_DIRS[e])
	var dur := _ms(_t("walk_in_ms", 450))
	var t := 0.0
	_play(step_player, step_streams[rng.randi_range(0, step_streams.size() - 1)])
	while t < dur:
		await get_tree().process_frame
		t += get_process_delta_time()
		explorer.position = start.lerp(target, clamp(t / dur, 0.0, 1.0))
		explorer.step(get_process_delta_time(), true)
	explorer.step(0.0, false)


# ================================================================ ratings, questionnaire, validation, pause

func _hold_step(action: String, held: Dictionary, dt: float) -> bool:
	## True on press, then repeatedly while held (after 0.35 s, every 0.07 s).
	if Input.is_action_just_pressed(action):
		held[action] = -0.35
		return true
	if Input.is_action_pressed(action):
		held[action] = held.get(action, 0.0) + dt
		if held[action] >= 0.07:
			held[action] = 0.0
			return true
	return false


func _show_rating_ui(question: String, mode_name: String) -> void:
	blackout.visible = true
	hud.visible = false
	rating_ui.visible = true
	rating_q.text = question
	var bar_mode := mode_name == "slider"
	for n in [rating_ui.get_node("bar"), rating_fill, rating_value, rating_left, rating_right]:
		n.visible = bar_mode
	choice_label.visible = mode_name == "choice"
	text_edit.visible = mode_name == "text"


## Slider from lo to hi. Returns [value, rt_ms].
func _slider(question: String, lo: int, hi: int, step: int, start: int, left: String, right: String, suffix: String) -> Array:
	_show_rating_ui(question, "slider")
	rating_left.text = left
	rating_right.text = right
	rating_hint.text = "LEFT / RIGHT to change, SPACE to confirm"
	var v := start
	var held := {}
	var t0 := Time.get_ticks_usec()
	var moved := false
	while true:
		var frac := float(v - lo) / float(hi - lo)
		rating_fill.size.x = 1000.0 * frac
		rating_value.text = "%d%s" % [v, suffix]
		await get_tree().process_frame
		var dt := get_process_delta_time()
		if autotest:
			v = lo + step * rng.randi_range(0, (hi - lo) / step)
			break
		if _hold_step("move_left", held, dt):
			v = max(lo, v - step)
			moved = true
		if _hold_step("move_right", held, dt):
			v = min(hi, v + step)
			moved = true
		if Input.is_action_just_pressed("continue") and Time.get_ticks_usec() - t0 > 500000:
			break
	rating_ui.visible = false
	return [v, snappedf((Time.get_ticks_usec() - t0) / 1000.0, 0.1), moved]


## Multiple choice. Returns [index, rt_ms].
func _choice(question: String, options: Array) -> Array:
	_show_rating_ui(question, "choice")
	rating_hint.text = "UP / DOWN to choose, SPACE to confirm"
	var idx := -1
	var t0 := Time.get_ticks_usec()
	while true:
		var lines: PackedStringArray = []
		for k in options.size():
			lines.append(("> " if k == idx else "   ") + options[k])
		choice_label.text = "\n".join(lines)
		await get_tree().process_frame
		if autotest:
			idx = rng.randi_range(0, options.size() - 1)
			break
		if Input.is_action_just_pressed("move_down"):
			idx = 0 if idx < 0 else min(options.size() - 1, idx + 1)
		if Input.is_action_just_pressed("move_up"):
			idx = 0 if idx < 0 else max(0, idx - 1)
		if Input.is_action_just_pressed("continue") and idx >= 0:
			break
	rating_ui.visible = false
	return [idx, snappedf((Time.get_ticks_usec() - t0) / 1000.0, 0.1)]


## Free text, submitted with ENTER. Returns [text, rt_ms].
func _free_text(question: String) -> Array:
	_show_rating_ui(question, "text")
	rating_hint.text = "Press ENTER when done (you can leave it empty)"
	var t0 := Time.get_ticks_usec()
	if autotest:
		rating_ui.visible = false
		return ["", 0.0]
	text_edit.text = ""
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	text_edit.grab_focus()
	var txt: String = await text_edit.text_submitted
	text_edit.release_focus()
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	rating_ui.visible = false
	return [txt, snappedf((Time.get_ticks_usec() - t0) / 1000.0, 0.1)]


const RATING_COLUMNS := ["pid", "mode", "epoch", "actual_reliability", "item", "value", "moved", "rt_ms", "t_us"]

## Explicit trust ratings at the end of each level.
func _level_ratings(epoch: int, actual: float) -> void:
	if not bool(cfg.get_value("ratings", "enabled", true)):
		return
	var t := logger.event("ratings_start", -1, {"epoch": epoch})
	var r1 := await _slider("Level %d is complete.\n\nIn this level, how often did the guide's tap come from the tunnel that led down?" % epoch,
			0, 100, 5, 50, "Never", "Always", "%")
	logger.append_csv("_ratings.csv", RATING_COLUMNS, {"pid": pid, "mode": mode, "epoch": epoch,
			"actual_reliability": actual, "item": "estimated_tap_accuracy", "value": r1[0], "moved": int(r1[2]), "rt_ms": r1[1], "t_us": t})
	var r2 := await _slider("In this level, when the tap and the chalk arrow pointed to different tunnels, which did you follow?",
			1, 7, 1, 4, "Always the chalk arrow", "Always the tap", "")
	logger.append_csv("_ratings.csv", RATING_COLUMNS, {"pid": pid, "mode": mode, "epoch": epoch,
			"actual_reliability": actual, "item": "reliance_tap_vs_chalk", "value": r2[0], "moved": int(r2[2]), "rt_ms": r2[1], "t_us": t})
	logger.event("ratings_end", -1, {"epoch": epoch, "estimated_tap_accuracy": r1[0], "reliance": r2[0]})


const Q_COLUMNS := ["pid", "mode", "item", "question", "response", "response_index", "rt_ms"]

## Short end-of-session questionnaire (gaming experience is the proposal's covariate).
func _questionnaire() -> void:
	logger.event("questionnaire_start")
	var items := [
		["gaming_hours", "About how many hours per week do you play video games?",
			["None", "Less than 2 hours", "2 to 5 hours", "5 to 10 hours", "More than 10 hours"]],
		["noticed_change", "Did the guide's tap seem more trustworthy in some levels than in others?",
			["Yes", "No", "Not sure"]],
		["strategy", "Overall, what did you rely on most to choose a tunnel?",
			["Mostly the tap", "Mostly the chalk arrows", "Both about equally", "Neither, I mostly guessed"]],
		["localization", "Could you tell which tunnel the tap came from?",
			["Always", "Usually", "Sometimes", "Rarely"]],
	]
	for it in items:
		var r := await _choice(it[1], it[2])
		logger.append_csv("_questionnaire.csv", Q_COLUMNS, {"pid": pid, "mode": mode, "item": it[0],
				"question": it[1], "response": it[2][r[0]], "response_index": r[0], "rt_ms": r[1]})
	var skill := await _slider("How skilled are you at video games?", 1, 7, 1, 4, "Not at all skilled", "Very skilled", "")
	logger.append_csv("_questionnaire.csv", Q_COLUMNS, {"pid": pid, "mode": mode, "item": "gaming_skill",
			"question": "How skilled are you at video games? (1-7)", "response": skill[0], "response_index": skill[0], "rt_ms": skill[1]})
	var txt := await _free_text("Anything else you noticed, or how you decided which tunnel to take?")
	logger.append_csv("_questionnaire.csv", Q_COLUMNS, {"pid": pid, "mode": mode, "item": "comments",
			"question": "Anything else you noticed, or how you decided which tunnel to take?", "response": txt[0], "response_index": "", "rt_ms": txt[1]})
	logger.event("questionnaire_end")


## Gaze validation: dots at known positions, each logged as a marker, so
## calibration accuracy and drift can be computed offline from the gaze stream.
func _run_validation(tag: String) -> void:
	if not bool(cfg.get_value("validation", "enabled", true)):
		return
	var margin := float(cfg.get_value("validation", "margin", 0.1))
	var ms := float(cfg.get_value("validation", "point_ms", 1200))
	var pts: Array = []
	for fy in [margin, 0.5, 1.0 - margin]:
		for fx in [margin, 0.5, 1.0 - margin]:
			pts.append(Vector2(REF.x * fx, REF.y * fy))
	var order: Array = range(pts.size())
	var r := RandomNumberGenerator.new()
	r.seed = hash(pid + tag)
	for i in range(order.size() - 1, 0, -1):
		var j := r.randi_range(0, i)
		var tmp = order[i]
		order[i] = order[j]
		order[j] = tmp
	hud.visible = false
	blackout.visible = true
	message.text = "Look at each dot until it disappears."
	message.visible = true
	await _wait(1500)
	message.visible = false
	logger.event("validation_start", -1, {"tag": tag})
	for k in order:
		val_target.position = pts[k]
		val_target.visible = true
		val_target.queue_redraw()
		logger.event("validation_point", -1, {"tag": tag, "index": k, "x": pts[k].x, "y": pts[k].y})
		await _wait(ms)
	val_target.visible = false
	logger.event("validation_end", -1, {"tag": tag})


## Experimenter pause (P). V runs a gaze validation before continuing.
func _pause_screen(g: int) -> void:
	pause_requested = false
	hint.text = ""
	hud.visible = false
	logger.event("pause_start", g)
	blackout.visible = true
	message.text = "Paused.\n\nSPACE: continue\nV: gaze validation, then continue"
	message.visible = true
	while true:
		await get_tree().process_frame
		if Input.is_action_just_pressed("continue"):
			break
		if Input.is_action_just_pressed("validate"):
			message.visible = false
			await _run_validation("pause_before_%d" % (g + 1))
			break
	message.visible = false
	logger.event("pause_end", g)


# ================================================================ localization test

func _run_localization(rows: Array) -> void:
	await _wait_continue("Sound check.\n\nYou will hear the guide's tap from one of the three tunnels.\n"
		+ "Press  LEFT,  UP  or  RIGHT  (or A, W, D) for the tunnel it came from.\n\n"
		+ "Look at the explorer in the centre.")
	_clear_props()
	_reset_explorer()
	chalk.visible = false
	var hits := [0, 0, 0]
	var counts := [0, 0, 0]
	var g := 0
	for row in rows:
		if aborting:
			break
		g += 1
		var e: int = row["cue_exit"]
		var res: Dictionary = row.duplicate()
		res["pid"] = pid
		res["mode"] = mode
		res["trial_global"] = g
		_set_lantern("clear")
		blackout.visible = false
		res["t_start_us"] = logger.event("start_on", g)
		await _wait(_t("start_ms", 500) + rng.randf_range(0, 500))
		if cue_streams[e] != null:
			cue_player.stream = cue_streams[e]
			cue_player.play()
		var t_cue := logger.event("cue_on", g, {"cue_exit": e})
		res["t_cue_us"] = t_cue
		var resp := await _respond_keys(t_cue, row)
		var choice: int = resp["choice_exit"]
		res.merge(resp, true)
		res["timeout"] = 1 if choice < 0 else 0
		res["correct"] = 1 if choice == e else 0
		res["followed_sound"] = res["correct"]
		if choice >= 0:
			res["rt_ms"] = snappedf((resp["t_response_us"] - t_cue) / 1000.0, 0.01)
		logger.event("response" if choice >= 0 else "timeout", g, {"choice_exit": choice})
		logger.trial(res)
		counts[e] += 1
		hits[e] += res["correct"]
		blackout.visible = true
		await _wait(_t("iti_ms", 500))
	var lines: PackedStringArray = []
	for e in 3:
		lines.append("%s: %d / %d" % [EXIT_NAMES[e], hits[e], counts[e]])
	var total: int = hits[0] + hits[1] + hits[2]
	var n: int = counts[0] + counts[1] + counts[2]
	var summary := "Localization: %d / %d correct (%.0f%%)\n\n%s" % [total, n, 100.0 * total / max(n, 1), "\n".join(lines)]
	logger.event("localization_summary", -1, {"hits": hits, "counts": counts})
	print(summary)
	await _wait_continue(summary)


# ================================================================ screenshots

func _shot(path: String) -> void:
	for f in 8:
		await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png(path)
	print("Saved ", path)


func _take_screenshots() -> void:
	var out := DataLogger.resolve_data_dir().path_join("screenshots")
	DirAccess.make_dir_recursive_absolute(out)
	mode = "live"
	pid_edit.text = "P004"
	pid_edit.text_changed.emit("P004")
	await _shot(out.path_join("ui_menu.png"))
	menu.visible = false
	message.text = _instructions() + "\n\n[Press SPACE to continue]"
	message.visible = true
	await _shot(out.path_join("ui_instructions.png"))
	message.visible = false
	blackout.visible = false
	depth = 12
	autotest = true
	time_scale = 0.01
	await _stage_card(2, 0)
	autotest = false
	time_scale = 1.0
	for l in [stage_title, stage_sub, stage_hint]:
		l.visible = true
		l.modulate.a = 1.0
	stage_hint.text = "Depth so far: %d\n\n[Press SPACE to continue]" % depth
	await _shot(out.path_join("stage_card.png"))
	for l in [stage_title, stage_sub, stage_hint]:
		l.visible = false
	hud.visible = true
	blackout.visible = false
	_reset_explorer()
	_set_lantern("start")
	await _shot(out.path_join("trial_start.png"))
	chalk.position = exit_point(0, _m("chalk_distance_px", 190.0))
	chalk.rotation = EXIT_DIRS[0].angle()
	chalk.visible = true
	for level in ["clear", "faded"]:
		_set_lantern(level)
		_set_chalk(level)
		await _shot(out.path_join("junction_%s.png" % level))
	_set_lantern("clear")
	_set_chalk("clear")
	time_scale = 1.0
	explorer.position = centre + Vector2(-120, 0)
	explorer.set_facing(Vector2.LEFT)
	await _walk_in(0, 0)
	banner.text = "The way down!"
	await _shot(out.path_join("feedback_way_down.png"))
	_clear_props()
	banner.text = ""
	_reset_explorer()
	await _walk_in(2, 0)
	banner.text = "Dead end!"
	var tr := Sprite2D.new()
	tr.texture = load("res://assets/sprites/trapdoor.png")
	tr.scale = Vector2.ONE * 150.0 / float(tr.texture.get_width())
	tr.position = exit_point(0, _m("reveal_distance_px", 420.0))
	tr.rotation = EXIT_DIRS[0].angle() + PI / 2.0
	props.add_child(tr)
	reveal_light.position = tr.position
	reveal_light.visible = true
	await _shot(out.path_join("feedback_dead_end.png"))
	reveal_light.visible = false
	banner.text = ""
	hud.visible = false
	_show_rating_ui("Level 2 is complete.\n\nIn this level, how often did the guide's tap come from the tunnel that led down?", "slider")
	rating_left.text = "Never"
	rating_right.text = "Always"
	rating_hint.text = "LEFT / RIGHT to change, SPACE to confirm"
	rating_fill.size.x = 650.0
	rating_value.text = "65%"
	await _shot(out.path_join("rating_level_end.png"))
	_show_rating_ui("Overall, what did you rely on most to choose a tunnel?", "choice")
	rating_hint.text = "UP / DOWN to choose, SPACE to confirm"
	choice_label.text = "   Mostly the tap\n> Mostly the chalk arrows\n   Both about equally\n   Neither, I mostly guessed"
	await _shot(out.path_join("questionnaire.png"))
	rating_ui.visible = false
	val_target.position = Vector2(REF.x * 0.1, REF.y * 0.1)
	val_target.visible = true
	await _shot(out.path_join("validation_dot.png"))
	get_tree().quit()
