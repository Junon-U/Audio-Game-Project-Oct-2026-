#!/usr/bin/env python3
"""Render the binaural cue files and the ambience loop for Cave Maze.

Cues: audio/stimuli/cue_00.wav, cue_01.wav, ... (one per direction)
----------------------------------------------------------------------
The explorer is always at the centre of the junction when the cue plays, so
each exit has one fixed direction and the cue can be rendered offline.
Every participant hears identical files.

Direction mapping: screen up = straight ahead, screen right = right ear.
Directions come from [cues] angles_deg in config/experiment.cfg (clockwise
from up; default left 270, ahead 0, right 90). Azimuth (SOFA convention,
positive = left) is minus that angle.

Spatialization (three layers):
  1. Left/right: interaural time and level differences. Default "enhanced"
     mode exaggerates them (ITD x1.3, ILD up to ~16 dB) so neighbouring slots
     are easier to tell apart. --natural uses realistic values; --sofa uses
     measured HRIRs (e.g. SADIE II KEMAR, subject D2, 48 kHz:
     https://www.york.ac.uk/sadie-project/database.html).
  2. Front/back: a brightness code. Sounds from the top of the screen are
     crisp, sounds from the bottom are muffled, changing smoothly with angle.
     Without it, mirror slots (e.g. 60 and 120 degrees) sound the same over
     headphones. On by default in every mode; --no-fb-code turns it off.
  3. Repetition: the guide taps --taps times (default 2), which gives the
     listener more than one look at the direction.
Run tools/check_cues.py afterwards to measure how distinguishable the cues are.

Tap: the Kenney "impactMining_002" pickaxe strike (CC0) by default, trimmed
to --max-ms and normalized. Use --tap FILE for another recording.
The same diffuse "cave echo" (identical for every slot) is added, so the
reverb never tells which cue is valid. All files share one gain.

A report with azimuths, ITDs, durations and levels is written to
audio/stimuli/stimuli_report.json for the methods section.

Requires: numpy, scipy, soundfile (h5py for --sofa).
"""
import argparse
import configparser
import glob
import json
import os
import sys

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, lfilter, fftconvolve, resample_poly

FS = 48000
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_TAP = os.path.join(ROOT, "assets", "kenney_audio", "impactMining_002.ogg")


def read_angles(cfg_path):
    """Cue directions in degrees clockwise from straight up ([cues] angles_deg)."""
    cp = configparser.ConfigParser(inline_comment_prefixes=(";",))
    cp.read(cfg_path)
    return [float(a) for a in json.loads(cp["cues"]["angles_deg"])]


def slot_azimuths(angles):
    out = []
    for ang in angles:
        ang = ang % 360.0                              # clockwise from up
        az = (-ang + 180.0) % 360.0 - 180.0            # positive = left
        out.append((ang, az))
    return out


def load_tap(path, max_ms):
    import soundfile as sf
    x, sr = sf.read(path, always_2d=True)
    x = x.mean(axis=1)
    if sr != FS:
        x = resample_poly(x, FS, sr)
    thr = 0.02 * np.max(np.abs(x))
    start = max(0, int(np.argmax(np.abs(x) > thr)) - int(0.002 * FS))
    x = x[start: start + int(max_ms / 1000 * FS)].copy()
    fade = min(int(0.03 * FS), len(x) // 3)
    x[-fade:] *= np.linspace(1, 0, fade)
    return x / np.max(np.abs(x))


def frac_delay(x, d):
    n = np.arange(len(x) + int(np.ceil(d)) + 2)
    return np.interp(n - d, np.arange(len(x)), x, left=0.0, right=0.0)


def brightness_code(y, az, fc=2000.0):
    """Front/back cue: high frequencies boosted for sources in front (top of the
    screen) and cut for sources behind (bottom), varying smoothly with angle.
    About +8 dB above 2 kHz straight ahead, near 0 dB at the sides, -20 dB behind."""
    g = 1.6 - 2.5 * abs(az) / 180.0
    b, a = butter(2, fc / (FS / 2), "high")
    out = np.empty_like(y)
    for ch in range(y.shape[1]):
        out[:, ch] = y[:, ch] + g * lfilter(b, a, y[:, ch])
    return out


def analytic_binaural(x, az, head_radius=0.0875, c=343.0, enhanced=True):
    """Woodworth ITD + head-shadow ILD from the lateral angle. Enhanced mode
    exaggerates both so that neighbouring slots differ more."""
    if abs(az) < 0.5 or abs(abs(az) - 180) < 0.5:
        return np.stack([x, x], axis=1), 0.0
    lateral = abs(az) if abs(az) <= 90 else 180 - abs(az)
    theta = np.deg2rad(lateral)
    itd = head_radius / c * (theta + np.sin(theta)) * (1.3 if enhanced else 1.0)
    near_gain = 10 ** ((2.0 if enhanced else 1.5) * np.sin(theta) / 20)
    far_gain = 10 ** ((-14.0 if enhanced else -6.0) * np.sin(theta) / 20)
    fc = 18000 * (1 - 0.8 * np.sin(theta)) + 1500
    b, a = butter(1, min(fc, FS / 2 - 100) / (FS / 2), "low")
    near = x * near_gain
    far = frac_delay(lfilter(b, a, x) * far_gain, itd * FS)
    near = np.concatenate([near, np.zeros(len(far) - len(near))])
    left, right = (near, far) if az > 0 else (far, near)
    return np.stack([left, right], axis=1), itd


def sofa_binaural(x, az, sofa_path):
    import h5py
    with h5py.File(sofa_path, "r") as f:
        ir = np.array(f["Data.IR"])
        pos = np.array(f["SourcePosition"])
        sr = float(np.array(f["Data.SamplingRate"]).ravel()[0])
    a = np.mod(pos[:, 0], 360)
    t = np.mod(az, 360)
    daz = np.minimum(np.abs(a - t), 360 - np.abs(a - t))
    idx = int(np.argmin(daz ** 2 + (pos[:, 1] * 2) ** 2))
    h = ir[idx]
    if sr != FS:
        h = np.stack([resample_poly(h[0], FS, int(sr)), resample_poly(h[1], FS, int(sr))])
    cc = np.correlate(h[0], h[1], mode="full")
    itd = abs((np.argmax(np.abs(cc)) - (len(h[1]) - 1)) / FS)
    return (np.stack([fftconvolve(x, h[0]), fftconvolve(x, h[1])], axis=1), itd,
            {"measured_az": float(pos[idx, 0]), "measured_el": float(pos[idx, 1])})


def diffuse_echo(x, rt60=0.3, predelay_ms=18, seed=11):
    rng = np.random.default_rng(seed)
    n = int(rt60 * FS)
    env = np.exp(-6.9 * np.arange(n) / FS / rt60)
    b, a = butter(2, 4000 / (FS / 2), "low")
    pre = np.zeros(int(predelay_ms / 1000 * FS))
    chans = []
    for _ in range(2):
        ir = np.concatenate([pre, lfilter(b, a, rng.standard_normal(n)) * env])
        w = fftconvolve(x, ir)
        chans.append(w / np.sqrt(np.mean(w ** 2)))
    return np.stack(chans, axis=1)


def ambience(seconds=20, seed=5):
    rng = np.random.default_rng(seed)
    n = seconds * FS
    brown = np.cumsum(rng.standard_normal(n + FS))
    brown -= np.convolve(brown, np.ones(4800) / 4800, mode="same")
    b, a = butter(2, 350 / (FS / 2), "low")
    amb = lfilter(b, a, brown)
    loop = amb[:n].copy()
    loop[:FS] = amb[:FS] * np.linspace(0, 1, FS) + amb[n:n + FS] * np.linspace(1, 0, FS)
    st = np.stack([loop, np.roll(loop, 3000)], axis=1)
    return st / np.max(np.abs(st)) * 10 ** (-6 / 20)


def rms_db(x):
    return float(20 * np.log10(np.sqrt(np.mean(np.square(x))) + 1e-12))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sofa", help="SOFA HRIR file (e.g. SADIE II D2 KEMAR 48 kHz)")
    ap.add_argument("--tap", default=DEFAULT_TAP, help="recording of a single strike (wav/ogg/flac)")
    ap.add_argument("--max-ms", type=float, default=170, help="length of one strike")
    ap.add_argument("--taps", type=int, default=2, help="number of strikes in the cue")
    ap.add_argument("--tap-gap-ms", type=float, default=180, help="onset-to-onset interval between strikes")
    ap.add_argument("--natural", action="store_true", help="realistic (not exaggerated) ITD/ILD in analytic mode")
    ap.add_argument("--no-fb-code", action="store_true", help="disable the front/back brightness code")
    ap.add_argument("--echo-db", type=float, default=-18.0, help="shared echo level re direct sound (dB); -inf disables")
    ap.add_argument("--max-total-ms", type=float, default=500, help="cue files are cut (with fade) to this length")
    ap.add_argument("--peak-dbfs", type=float, default=-3.0)
    ap.add_argument("--config", default=os.path.join(ROOT, "config", "experiment.cfg"))
    args = ap.parse_args()

    angles = read_angles(args.config)
    strike = load_tap(args.tap, args.max_ms)
    gap = int(args.tap_gap_ms / 1000 * FS)
    tap = np.zeros(gap * (args.taps - 1) + len(strike))
    for k in range(args.taps):
        tap[k * gap: k * gap + len(strike)] += strike * (1.0 if k == 0 else 0.9)
    tap /= np.max(np.abs(tap))
    echo = diffuse_echo(tap) if np.isfinite(args.echo_db) else None
    out_dir = os.path.join(ROOT, "audio", "stimuli")
    os.makedirs(out_dir, exist_ok=True)
    for old in glob.glob(os.path.join(out_dir, "cue_*.wav")):
        os.remove(old)

    report = {"sample_rate": FS,
              "method": "sofa" if args.sofa else ("analytic_natural" if args.natural else "analytic_enhanced_itd_x1.3_ild_16db"),
              "front_back_brightness_code": not args.no_fb_code, "taps": args.taps, "tap_gap_ms": args.tap_gap_ms,
              "sofa_file": os.path.basename(args.sofa) if args.sofa else None,
              "tap_source": os.path.basename(args.tap), "strike_ms": args.max_ms, "cue_core_ms": round(len(tap) / FS * 1000, 1),
              "echo_level_db": args.echo_db, "angles_deg": angles, "slots": []}
    rendered = []
    for k, (ang, az) in enumerate(slot_azimuths(angles)):
        if args.sofa:
            y, itd, extra = sofa_binaural(tap, az, args.sofa)
        else:
            y, itd = analytic_binaural(tap, az, enhanced=not args.natural)
            extra = {}
        if not args.no_fb_code:
            y = brightness_code(y, az)
        if echo is not None:
            mix = np.zeros((max(len(y), len(echo)), 2))
            mix[: len(y)] += y
            mix[: len(echo)] += echo * np.sqrt(np.mean(y ** 2)) * 10 ** (args.echo_db / 20)
            y = mix
        cut = int(args.max_total_ms / 1000 * FS)
        if len(y) > cut:
            y = y[:cut].copy()
        fade = int(0.03 * FS)
        y[-fade:] *= np.linspace(1, 0, fade)[:, None]
        rendered.append(y)
        report["slots"].append({"slot": k, "screen_angle_deg": round(ang, 2), "azimuth_deg": round(az, 2),
                                "itd_us": round(float(itd) * 1e6, 1), **extra})

    gain = 10 ** (args.peak_dbfs / 20) / max(np.max(np.abs(r)) for r in rendered)
    for k, y in enumerate(rendered):
        y = y * gain
        path = os.path.join(out_dir, "cue_%02d.wav" % k)
        wavfile.write(path, FS, (y * 32767).astype(np.int16))
        report["slots"][k].update({"file": os.path.basename(path), "duration_ms": round(len(y) / FS * 1000, 1),
                                   "rms_dbfs_left": round(rms_db(y[:, 0]), 2), "rms_dbfs_right": round(rms_db(y[:, 1]), 2)})
        print("%s  angle %6.1f  az %6.1f  ITD %5.0f us  L %.1f  R %.1f dBFS" % (
            os.path.basename(path), report["slots"][k]["screen_angle_deg"], report["slots"][k]["azimuth_deg"],
            report["slots"][k]["itd_us"], report["slots"][k]["rms_dbfs_left"], report["slots"][k]["rms_dbfs_right"]))
    with open(os.path.join(out_dir, "stimuli_report.json"), "w") as f:
        json.dump(report, f, indent=2)

    amb = ambience()
    wavfile.write(os.path.join(ROOT, "audio", "ambience_loop.wav"), FS, (amb * 32767).astype(np.int16))
    print("wrote audio/ambience_loop.wav")
    print("Open the project in Godot afterwards so it re-imports the files.")
    if not args.sofa:
        print("Note: analytic placeholder used. For data collection, render with --sofa.", file=sys.stderr)


if __name__ == "__main__":
    main()
