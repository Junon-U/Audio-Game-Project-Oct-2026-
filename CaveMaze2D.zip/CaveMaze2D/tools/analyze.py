#!/usr/bin/env python3
"""Merge Cave Maze sessions and produce first-pass tables and figures.

Usage:
    python tools/analyze.py                 # reads data/, writes analysis/
    python tools/analyze.py --data DIR --out DIR --include-autotest

Outputs (in analysis/):
  trials_all.csv            every junction from every live/replay session, with
                            derived columns, ready for mixed models (R lme4 / Python)
  summary_by_level.csv      per participant x mode x level: accuracy, sound-following,
                            chalk-following on conflict junctions, RT, timeouts,
                            invalid-cue cost, and the explicit rating
  summary_by_condition.csv  accuracy / sound-following by audio condition x visibility x level
  ratings.csv               level-end ratings next to the actual reliability
  questionnaire.csv         questionnaire answers, one row per participant x mode
  localization.csv          localization accuracy per participant and direction
  sound_following_<mode>.png  running sound-following rate across junctions, by condition

Derived columns in trials_all.csv:
  r_hat               proposal estimate, recomputed (alpha0 = beta0 = 1, silent excluded)
  r_hat_recent        estimate from the last --window audio junctions only (a faster-
                      adapting alternative for the model comparison)
  conflict            1 if the tap and the chalk pointed to different tunnels
  trial_in_level      junction number within the level (for adaptation analyses, H3)
  half                first / second half of the level

Gaze measures (next fixation, first-saccade latency) need the eye-tracking
stream: align it to the cue_on markers in the XDF file recorded by LabRecorder
and use the AOI positions in trials_all.csv (correct_x/y, cue_x/y, chalk_x/y)
or in *_session.json.
"""
import argparse
import glob
import json
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(pattern, include_autotest):
    frames = []
    for f in sorted(glob.glob(pattern)):
        name = os.path.basename(f)
        if name.startswith("AUTOTEST") and not include_autotest:
            continue
        d = pd.read_csv(f)
        d["session_file"] = name
        frames.append(d)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def add_estimates(t, window):
    out = []
    for _, s in t.groupby("session_file", sort=False):
        s = s.sort_values("trial_global").copy()
        na = nv = 0
        recent = []
        r_hat, r_recent = [], []
        for _, row in s.iterrows():
            if row["epoch"] > 0:
                r_hat.append((1 + nv) / (2 + na))
                r_recent.append((1 + sum(recent[-window:])) / (2 + len(recent[-window:])))
                if row["cue_exit"] >= 0:
                    v = int(row["cue_exit"] == row["correct_exit"])
                    na += 1
                    nv += v
                    recent.append(v)
            else:
                r_hat.append(np.nan)
                r_recent.append(np.nan)
        s["r_hat_check"] = r_hat
        s["r_hat_recent"] = r_recent
        out.append(s)
    return pd.concat(out)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", default=os.path.join(ROOT, "data"))
    ap.add_argument("--out", default=os.path.join(ROOT, "analysis"))
    ap.add_argument("--window", type=int, default=10, help="audio junctions in r_hat_recent")
    ap.add_argument("--include-autotest", action="store_true")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    t = load(os.path.join(args.data, "*_trials.csv"), args.include_autotest)
    if t.empty:
        sys.exit("No *_trials.csv files found in %s" % args.data)
    loc = t[t["block"] == "localization"].copy()
    t = t[t["block"] != "localization"].copy()

    # ---- derived columns
    t = add_estimates(t, args.window)
    if "r_hat" in t and t["r_hat"].notna().any():
        diff = (t["r_hat"] - t["r_hat_check"]).abs().max()
        if diff > 1e-3:
            print("Warning: logged r_hat differs from recomputation by up to %.4f" % diff)
    t["conflict"] = ((t["cue_exit"] >= 0) & (t["cue_exit"] != t["chalk_exit"])).astype(int)
    t["trial_in_level"] = t["trial_in_block"]
    n_level = t.groupby(["session_file", "block"])["trial_in_block"].transform("max")
    t["half"] = np.where(t["trial_in_block"] <= n_level / 2, "first", "second")
    t["responded"] = (t["timeout"] == 0).astype(int)
    t.to_csv(os.path.join(args.out, "trials_all.csv"), index=False)

    main_t = t[t["epoch"] > 0]
    audio = main_t[main_t["cue_exit"] >= 0]

    # ---- per level
    rows = []
    for (pid, mode, ep), g in main_t.groupby(["pid", "mode", "epoch"]):
        a = g[g["cue_exit"] >= 0]
        resp = g[g["timeout"] == 0]
        conf = resp[resp["conflict"] == 1]
        valid = a[a["audio_cond"] == "valid"]
        invalid = a[a["audio_cond"] == "invalid"]
        rows.append({
            "pid": pid, "mode": mode, "level": ep,
            "reliability": g["reliability"].iloc[0],
            "reliability_condition": g["reliability_condition"].iloc[0],
            "n_junctions": len(g),
            "accuracy": g["correct"].mean(),
            "timeouts": int(g["timeout"].sum()),
            "follow_sound": a.loc[a["timeout"] == 0, "followed_sound"].mean(),
            "follow_sound_first_half": a.loc[(a["timeout"] == 0) & (a["half"] == "first"), "followed_sound"].mean(),
            "follow_sound_second_half": a.loc[(a["timeout"] == 0) & (a["half"] == "second"), "followed_sound"].mean(),
            "follow_chalk_on_conflict": conf["followed_chalk"].mean() if len(conf) else np.nan,
            "acc_valid_cue": valid["correct"].mean(),
            "acc_invalid_cue": invalid["correct"].mean() if len(invalid) else np.nan,
            "acc_silent": g.loc[g["audio_cond"] == "silent", "correct"].mean(),
            "invalid_cue_cost": (valid["correct"].mean() - invalid["correct"].mean()) if len(invalid) else np.nan,
            "median_rt_ms": resp["rt_ms"].median(),
        })
    by_level = pd.DataFrame(rows)

    # ---- ratings
    ratings = load(os.path.join(args.data, "*_ratings.csv"), args.include_autotest)
    if not ratings.empty:
        wide = ratings.pivot_table(index=["pid", "mode", "epoch"], columns="item", values="value", aggfunc="last").reset_index()
        wide = wide.rename(columns={"epoch": "level"})
        by_level = by_level.merge(wide, on=["pid", "mode", "level"], how="left")
        ratings.to_csv(os.path.join(args.out, "ratings.csv"), index=False)
    by_level.round(4).to_csv(os.path.join(args.out, "summary_by_level.csv"), index=False)

    # ---- by condition
    cond = (main_t.groupby(["epoch", "audio_cond", "visibility"])
            .agg(n=("correct", "size"), accuracy=("correct", "mean"),
                 follow_sound=("followed_sound", "mean"), follow_chalk=("followed_chalk", "mean"),
                 median_rt_ms=("rt_ms", "median"))
            .reset_index().rename(columns={"epoch": "level"}))
    cond.round(4).to_csv(os.path.join(args.out, "summary_by_condition.csv"), index=False)

    # ---- questionnaire
    q = load(os.path.join(args.data, "*_questionnaire.csv"), args.include_autotest)
    if not q.empty:
        q.pivot_table(index=["pid", "mode"], columns="item", values="response", aggfunc="last").reset_index() \
            .to_csv(os.path.join(args.out, "questionnaire.csv"), index=False)

    # ---- localization
    if not loc.empty:
        names = {0: "left", 1: "ahead", 2: "right"}
        l = loc.assign(direction=loc["cue_exit"].map(names)).groupby(["pid", "direction"])["correct"].agg(["mean", "size"]).reset_index()
        l.rename(columns={"mean": "accuracy", "size": "n"}).to_csv(os.path.join(args.out, "localization.csv"), index=False)

    # ---- figures: running sound-following by reliability condition, one per mode
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        for mode_name, am in audio[audio["timeout"] == 0].groupby("mode"):
            a = am.copy()
            a["k"] = a.groupby("session_file").cumcount()
            a["follow_run"] = a.groupby("session_file")["followed_sound"].transform(lambda x: x.rolling(10, min_periods=3).mean())
            conds = sorted(a["reliability_condition"].unique())
            fig, axes = plt.subplots(len(conds), 1, figsize=(9, 2.2 * len(conds)), sharex=True, squeeze=False)
            for ax, c in zip(axes[:, 0], conds):
                sub = a[a["reliability_condition"] == c]
                for _, s_ in sub.groupby("session_file"):
                    ax.plot(s_["k"], s_["follow_run"], color="0.6", lw=0.8)
                mean = sub.groupby("k")["follow_run"].mean()
                ax.plot(mean.index, mean.values, color="black", lw=2)
                first = sub[sub["session_file"] == sub["session_file"].iloc[0]]
                for ep, e in first.groupby("epoch"):
                    ax.axvline(e["k"].min(), color="0.85", lw=1)
                    ax.hlines(e["reliability"].iloc[0], e["k"].min(), e["k"].max(), colors="tab:orange", lw=1.5)
                r = first.groupby("epoch")["reliability"].first().tolist()
                n = sub["pid"].nunique()
                ax.set_title("Condition %d: reliability %s (n = %d)" % (c, " / ".join("%d%%" % round(x * 100) for x in r), n),
                             fontsize=9, loc="left")
                ax.set_ylim(0, 1.05)
                ax.set_ylabel("follow tap")
            axes[-1, 0].set_xlabel("audio junction (responded)")
            fig.suptitle("%s: running proportion of choices following the tap (10-junction window); "
                         "grey = participants, black = mean, orange = actual reliability" % mode_name.capitalize(), fontsize=9)
            fig.tight_layout()
            fig.savefig(os.path.join(args.out, "sound_following_%s.png" % mode_name), dpi=130)
            plt.close(fig)
    except ImportError:
        print("matplotlib not installed; skipping the figures")

    n_p = main_t["pid"].nunique()
    print("Merged %d junctions from %d participant(s), %d session(s). Output: %s" % (
        len(t), n_p, t["session_file"].nunique(), args.out))


if __name__ == "__main__":
    main()
