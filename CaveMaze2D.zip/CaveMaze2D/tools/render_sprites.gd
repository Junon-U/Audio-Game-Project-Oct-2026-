extends SceneTree
## Renders the 2D sprites for Cave Maze from the Kenney Modular Cave Kit
## (CC0, assets/kenney_cave) with a top-down orthographic camera:
##   assets/sprites/junction.png  1920x1080 four-way corridor junction
##                                (entry from the bottom; exits left, ahead, right)
##   assets/sprites/rubble.png    rock cluster that blocks a dead end
##   assets/sprites/trapdoor.png  wooden boards over the way down
## The PNGs are included; re-run only to change the look:
##   godot --path . --rendering-driver opengl3 -s tools/render_sprites.gd
## (needs a display; on a headless Linux machine prefix with xvfb-run -a)
##
## Lighting is from straight above with four weak symmetric side lights and
## no shadows, so no corridor is brighter than another. The game adds its own
## darkness and lantern on top.

const OUT := "res://assets/sprites/"
const PX_PER_UNIT := 54.0

var vp: SubViewport
var world: Node3D
var cam: Camera3D


func _piece(name: String, pos: Vector3, rot_deg: float) -> Node3D:
	var s: Node3D = load("res://assets/kenney_cave/%s.glb" % name).instantiate()
	s.position = pos
	s.rotation_degrees.y = rot_deg
	world.add_child(s)
	return s


func _capture(path: String) -> void:
	vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	for k in 20:
		await process_frame
	vp.get_texture().get_image().save_png(path)
	print("saved ", path)


func _init() -> void:
	var args := OS.get_cmdline_user_args()
	var corridor_rot := 90.0   # corridor-wide runs along x at rotation 90
	for a in args:
		if a.begins_with("--crot="):
			corridor_rot = float(a.get_slice("=", 1))

	vp = SubViewport.new()
	vp.size = Vector2i(1920, 1080)
	vp.msaa_3d = Viewport.MSAA_8X
	vp.own_world_3d = true
	get_root().add_child(vp)
	world = Node3D.new()
	vp.add_child(world)

	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.09, 0.08, 0.10)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color.WHITE
	env.ambient_light_energy = 0.55
	env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	var we := WorldEnvironment.new()
	we.environment = env
	world.add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-90, 0, 0)
	sun.light_energy = 0.7
	world.add_child(sun)
	for yaw in [0.0, 90.0, 180.0, 270.0]:
		var side := DirectionalLight3D.new()
		side.rotation_degrees = Vector3(-35, yaw, 0)
		side.light_energy = 0.12
		world.add_child(side)

	cam = Camera3D.new()
	cam.projection = Camera3D.PROJECTION_ORTHOGONAL
	cam.position = Vector3(0, 40, 0)
	cam.rotation_degrees = Vector3(-90, 0, 0)
	cam.far = 100
	cam.size = 1080.0 / PX_PER_UNIT
	world.add_child(cam)

	# ---- junction: wide four-way intersection with wide corridors running
	# to the screen edges in all four directions.
	var nodes: Array[Node3D] = []
	nodes.append(_piece("corridor-wide-intersection", Vector3.ZERO, 0))
	for k in [1, 2, 3]:
		var d: float = 8.0 * k
		nodes.append(_piece("corridor-wide", Vector3(-d, 0, 0), corridor_rot + 90.0))
		nodes.append(_piece("corridor-wide", Vector3(d, 0, 0), corridor_rot + 90.0))
		if k <= 1:
			nodes.append(_piece("corridor-wide", Vector3(0, 0, -d), corridor_rot))
			nodes.append(_piece("corridor-wide", Vector3(0, 0, d), corridor_rot))
	await _capture(OUT + "junction.png")
	for n in nodes:
		n.queue_free()

	# ---- small sprites on a transparent background
	vp.transparent_bg = true
	env.background_mode = Environment.BG_CLEAR_COLOR
	vp.size = Vector2i(256, 256)
	cam.size = 3.0
	var rock := _piece("template-detail", Vector3.ZERO, 0)
	await _capture(OUT + "rubble.png")
	rock.queue_free()
	cam.size = 4.4
	_piece("template-floor-layer", Vector3.ZERO, 0)
	await _capture(OUT + "trapdoor.png")
	quit()
