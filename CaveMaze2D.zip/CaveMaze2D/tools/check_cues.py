#!/usr/bin/env python3
"""Measure how distinguishable the cue files are.

For each audio/stimuli/cue_slot_XX.wav it reports the interaural time
difference (ITD), interaural level difference (ILD) and spectral centroid
(brightness), then lists the pairs of slots whose cues are most alike.
Two slots whose ITD, ILD and brightness are all nearly equal will be
confused by listeners, typically front/back mirror pairs.

Usage: python tools/check_cues.py
"""
import glob
import os

import numpy as np
from scipy.io import wavfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def features(path):
    sr, x = wavfile.read(path)
    x = x.astype(np.float64) / 32768.0
    l, r = x[:, 0], x[:, 1]
    n = int(0.0015 * sr)  # ITD search range +-1.5 ms
    cc = [np.dot(l[max(0, -k):len(l) - max(0, k)], r[max(0, k):len(r) - max(0, -k)]) for k in range(-n, n + 1)]
    itd_us = (np.argmax(cc) - n) / sr * 1e6  # positive = right ear lags (source on the left)
    ild_db = 10 * np.log10(np.sum(l ** 2) / np.sum(r ** 2))  # positive = louder on the left
    mono = l + r
    spec = np.abs(np.fft.rfft(mono))
    f = np.fft.rfftfreq(len(mono), 1 / sr)
    centroid = float(np.sum(f * spec) / np.sum(spec))
    return itd_us, ild_db, centroid


def main():
    files = sorted(glob.glob(os.path.join(ROOT, "audio", "stimuli", "cue_*.wav")))
    feats = np.array([features(p) for p in files])
    print("slot   ITD(us)   ILD(dB)   brightness(Hz)")
    for k, (itd, ild, cen) in enumerate(feats):
        print("%3d  %8.0f  %8.1f  %10.0f" % (k, itd, ild, cen))
    # Distance in units of a just-noticeable difference (rough values for
    # broadband clicks over headphones): ITD 40 us, ILD 1 dB, centroid 8%.
    pairs = []
    for i in range(len(feats)):
        for j in range(i + 1, len(feats)):
            d_itd = abs(feats[i, 0] - feats[j, 0]) / 40.0
            d_ild = abs(feats[i, 1] - feats[j, 1]) / 1.0
            d_cen = abs(np.log(feats[i, 2] / feats[j, 2])) / np.log(1.08)
            pairs.append((np.sqrt(d_itd ** 2 + d_ild ** 2 + d_cen ** 2), i, j))
    pairs.sort()
    print("\nMost similar pairs (distance in approximate just-noticeable differences; < 3 is hard to tell apart):")
    for d, i, j in pairs[:6]:
        print("  slot %2d vs %2d: %.1f" % (i, j, d))


if __name__ == "__main__":
    main()
