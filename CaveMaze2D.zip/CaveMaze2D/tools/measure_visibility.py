#!/usr/bin/env python3
"""Measure the chalk arrow's visibility for each visibility level from the
screenshots made with `-- --shots` (data/screenshots/junction_*.png).
Reports the arrow's luminance contrast against the floor next to it and the
mean screen luminance (0-255 pixel values; confirm with a photometer)."""
import os
import sys
import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
shots = os.path.join(ROOT, "data", "screenshots")
cx, cy = 960, 540
dist = float(sys.argv[1]) if len(sys.argv) > 1 else 190.0   # chalk_distance_px
size = float(sys.argv[2]) if len(sys.argv) > 2 else 56.0    # chalk_size_px
ax = int(cx - dist)
for level in ["clear", "faded"]:
    img = np.asarray(Image.open(os.path.join(shots, "junction_%s.png" % level)).convert("L"), float)
    h = int(size / 2)
    box = img[cy - h: cy + h, ax - h: ax + h]
    arrow = box[box > np.percentile(box, 85)].mean()      # brightest strokes
    floor = img[cy - h: cy + h, ax + h + 10: ax + 3 * h + 10].mean()  # floor beside it
    print("%-6s arrow %.1f  floor %.1f  Weber contrast %.2f  screen mean %.1f" % (
        level, arrow, floor, (arrow - floor) / max(floor, 1), img.mean()))
