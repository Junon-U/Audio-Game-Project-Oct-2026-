# Cave Maze

Top-down 2D junction maze for "Learning When to Trust Sound". Godot 4.5, built with the Kenney Modular Cave Kit, Impact Sounds and Interface Sounds (all CC0).

The explorer descends through a dark cave. Every junction is one trial: the explorer stands at the centre of a four-way junction (having come from below) and picks the left, ahead or right tunnel. One leads down to a trapdoor; the other two are dead ends that cost time. Two imperfect sources of evidence:

- **Sound:** the guide's double pickaxe tap from down one tunnel (valid, invalid or silent).
- **Vision:** a chalk arrow on the floor at one tunnel's mouth, right on 75% of junctions, either clear or faded.

## Why a junction maze

- **Clean trials.** Each junction has one sound, one choice, one gaze outcome and one reliability update. There is no backtracking and no maze to memorize; a wrong turn costs a fixed time penalty.
- **Easy sound localization.** You always arrive from below, so the tap only comes from the left, ahead or right, never from behind. `tools/check_cues.py` puts the three cues about 26 just-noticeable differences apart (the 12-slot Cave Search managed about 4).
- **Matched brightness.** Visual uncertainty is the chalk's legibility, not darkness. The lantern is the same on every junction, so screen brightness and pupil size do not change with condition (measured: identical mean screen luminance; arrow contrast 0.31 clear vs 0.07 faded).
- **Identical scenes.** The junction geometry, exit positions and lantern are the same on every trial; only the chalk position/legibility and the sound differ.

## Mapping to the proposal

| Proposal | Here |
|---|---|
| Avatar at screen centre | Explorer at the junction centre |
| Target among distractors | Correct tunnel among three |
| Visual uncertainty (proposal: clutter) | Clear vs faded chalk arrow; brightness matched |
| Spatialized sound from target or distractor | Binaural double tap from the correct or another tunnel |
| Reliability epochs, 10 to 15% silent | Epoch 1 at 100%; epochs 2 and 3 assigned per participant; 12.5% silent |
| Live play vs replay | Live: steer with WASD / arrows into a tunnel. Replay: press LEFT / UP / RIGHT; the explorer walks there |
| Timing | Start 500 ms > preview 1000 to 1500 ms (movement locked) > cue > 2500 ms response window > walk-in > feedback 600 ms (+1000 ms after a dead end or timeout) > ITI 500 ms |

The visual manipulation differs from the proposal (clutter becomes chalk legibility); report it in the methods.

## Quick start

1. Install Godot 4.5 or later and Python 3.9+.
2. `pip install -r tools/requirements.txt`
3. Open the folder in Godot (Import > `project.godot`) and press F5.
4. Enter a participant ID (the screen shows its reliability condition), choose a mode, click Start.

## Sound reliability per participant

Epoch 1 is always 100% valid, so participants first learn the tap is trustworthy. Epochs 2 and 3 each take a value from `epoch_reliability_2_options` / `epoch_reliability_3_options` (default 40%, 55%, 70%); epoch 3 always differs from epoch 2. That gives 6 conditions. They rotate with the number in the participant ID (P001 condition 1, P002 condition 2, ... P007 condition 1), so 36 participants gives 6 per condition. IDs without a number get a random but reproducible condition. Participants are only told the tap may sometimes be wrong.

Each level has 36 junctions (`trials_per_epoch`; 3 exits x 2 chalk visibilities x 6), which covers the 14 to 40 trials after a reliability change in which Bleser et al. (2026) saw participants adapt. That is below the 1,600 observations per condition recommended by Brysbaert & Stevens (2018) at 36 participants, so analyse all levels in one hierarchical model (Waltmann et al., 2022); 52 participants reach 1,600 per level. With 12.5% silent, that is 31 tapped junctions per level. A full session is 6 practice + 3 x 36 = 114 junctions, about 12 minutes of play. Keep the value a multiple of 6.

## Levels (stage indicator)

Each reliability epoch is presented as a level of the cave: Level 1 "The Upper Caves", Level 2 "The Middle Depths", Level 3 "The Deep Caverns". A title card with a short sound marks the start of each level (after practice, and after each rest), and the corner of the screen shows the current level and depth during play. The card is logged as a `stage_card` marker.

The cards deliberately say nothing about the guide or the sound. Participants know a new level has begun but have to discover from experience whether the tap has become more or less trustworthy, which is what the reliability-updating hypotheses test. Report the level cards in the methods, because they mark the epoch boundaries for participants. Names and timing are in `[stages]` of the config; `announce=false` removes the cards (the rest screens remain).

## Measures added for the paper

**Reliability estimate (r_hat).** Each trial row carries the proposal's estimate of the participant's current sound reliability, computed from the junctions before it: `r_hat = (alpha0 + previous valid taps) / (alpha0 + beta0 + previous audio junctions)`, with alpha0 = beta0 = 1, silent junctions not updating it, and practice excluded (`[estimate]` in the config). `n_audio_prev` and `n_valid_prev` are logged too, plus `cue_valid` and `cue_chalk` (agree / conflict / no_cue). The main gaze and action models in the proposal use r_hat as a predictor directly. `tools/analyze.py` recomputes it as a check and adds a faster-adapting alternative (`r_hat_recent`, last 10 audio junctions) for the model comparison.

**The way down is shown after every mistake.** After a dead end or a timeout, the trapdoor in the correct tunnel lights up. Participants can then see on every junction whether the tap was right, which the r_hat formula assumes. Without it, someone who followed the chalk into a dead end could not tell whether the tap had been right. Turn it off with `reveal_correct_on_error=false`.

**Trust ratings at the end of each level** (`*_ratings.csv`): how often the tap came from the right tunnel (0 to 100%), and which cue the participant followed when the tap and chalk disagreed (1 = always chalk, 7 = always tap). They give an explicit measure to set against the behavioural estimate (does stated trust track the actual and estimated reliability?). They are asked only after a level ends, so they cannot influence behaviour within it. `moved` records whether the slider was moved from its starting point.

**Gaze validation** (start, after each rest, end; or any time via the pause key): nine dots at known positions, each logged as a `validation_point` marker with its x, y. Compute accuracy and drift offline from the gaze stream; this supports the preregistered calibration-error exclusion rule.

**Experimenter pause.** Press P during play; the game pauses after the current junction. SPACE continues, V runs a gaze validation first (e.g. after recalibrating). Logged as pause_start / pause_end.

**End-of-session questionnaire** (`*_questionnaire.csv`): gaming hours per week and self-rated skill (the proposal's covariate), whether the tap seemed more trustworthy in some levels (awareness), main strategy, how well the tap could be localized, and an optional comment.

**Analysis script.** `python tools/analyze.py` merges all sessions in `data/` into `analysis/trials_all.csv` (one row per junction with derived columns, ready for mixed models) and writes per-level summaries (accuracy, sound-following, chalk-following on conflict junctions, first vs second half of each level, invalid-cue cost, RT, ratings), condition summaries, localization accuracy, questionnaire answers, and a figure per mode of the running sound-following rate against the actual reliability. Gaze outcomes need the eye-tracking stream: align it to the `cue_on` markers and use the AOI columns.

## Before data collection

1. **Run the localization test** in the pilot (should be near 100% with three directions).
2. **Tune the faded chalk.** `faded_chalk_alpha` sets how hard it is to read. Aim for faded arrows that are visible when looked at but not noticed at a glance. After changing it, run with `-- --shots` and `python tools/measure_visibility.py` to check contrast and that screen brightness stays matched.
3. **Validate timing** once with a loopback recording of the headphone output against the `cue_on` markers.
4. Optional: `python tools/make_stimuli.py --sofa <file>` renders the cues with a measured HRTF instead of the enhanced analytic version (see the script's help).

## Session procedure

1. Start the eye tracker and its LSL outlet; calibrate.
2. `python tools/lsl_bridge.py`
3. Start LabRecorder; record the gaze stream and `CaveMazeMarkers`.
4. Run the localization test, then Replay and Live play.

Run fullscreen on a 1920x1080 monitor so logged positions equal screen pixels (scaling is saved in `_session.json` otherwise). ESC twice aborts after the current junction.

## Data (`data/`)

Files are named `<ID>_<mode>_<date-time>_*`: `_trials.csv` (one row per junction), `_events.csv` (every marker), `_paths.csv` (explorer position every frame of the response window, live mode), `_ratings.csv`, `_questionnaire.csv`, `_schedule.csv`, `_session.json` (settings, exit and chalk AOI positions, reliability assignment, screen scaling, audio latency).

Exit codes: 0 left, 1 ahead, 2 right, -1 none.

| Column | Meaning |
|---|---|
| reliability, reliability_condition | that epoch's sound reliability; the participant's condition |
| audio_cond, visibility | valid / invalid / silent; clear / faded chalk |
| correct_exit, cue_exit, chalk_exit, chalk_valid | trial structure |
| choice_exit, correct, followed_sound, followed_chalk, timeout, rt_ms | response (rt from cue onset) |
| first_move_ms, first_move_angle_deg, first_move_exit | first movement past 25 px (live) |
| first_move_to_sound / _target / _chalk | first action toward the tap, the correct tunnel, the chalk |
| path_length_px | explorer path length (live) |
| early_inputs | key presses before the cue (ignored) |
| depth | running score |
| cue_valid, cue_chalk | tap right (1/0, empty if silent); tap and chalk agree / conflict / no_cue |
| n_audio_prev, n_valid_prev, r_hat | the proposal's reliability estimate before this junction |
| correct_x/y, cue_x/y, chalk_x/y | screen positions for gaze AOIs |

Schedules are generated from the participant ID (same ID, same schedule). Within each epoch: correct tunnel balanced over the three exits, visibility balanced within each audio condition, chalk validity exactly 75% within each visibility level. To fix a schedule in advance: run with `-- --make-schedule=P001` (writes `schedules/P001.csv`, used automatically for that ID).

## Files

```
config/experiment.cfg       all settings
scripts/main.gd             session flow, junction trials, input, lantern, localization test, screenshots
scripts/schedule.gd         schedule generation, reliability assignment, CSV in/out
scripts/data_logger.gd      CSV logging, UDP markers
scripts/explorer.gd         explorer drawing
scripts/chalk_arrow.gd      chalk arrow drawing
assets/sprites/             junction, trapdoor, rubble rendered from the Kenney cave kit
assets/kenney_cave/         Kenney Modular Cave Kit models (CC0)
assets/kenney_audio/        Kenney pickaxe, footstep, wood, thud and interface sounds (CC0)
audio/stimuli/              binaural cue files (generated)
tools/make_stimuli.py       renders the cues and the ambience
tools/check_cues.py         measures how distinguishable the cues are
tools/measure_visibility.py chalk contrast and screen brightness from screenshots
tools/render_sprites.gd     re-renders the sprites from the cave kit
tools/lsl_bridge.py         UDP markers to LSL
tools/analyze.py            merges sessions, summary tables and figures
docs/                       screenshots
```

Command-line options (after `--`): `--autotest` or `--autotest-mode=replay|localization` (fast simulated session; `--autotest-pid=P003` sets the ID), `--make-schedule=<ID>`, `--shots` (screenshots to `data/screenshots/`).

Assets by Kenney (www.kenney.nl), CC0.
